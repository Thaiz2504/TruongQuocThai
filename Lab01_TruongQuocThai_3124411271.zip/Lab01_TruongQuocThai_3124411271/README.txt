LAB01 - NGON NGU LAP TRINH C#

Sinh vien: Truong Quoc Thai
MSSV: 3124411271
Lop: DCT124C4

Cau truc:
- Code/: ma nguon va solution cua Lab01
- BaoCao_Lab01_TruongQuocThai_3124411271.docx: bao cao thuc hanh

Luu y:
- Khong bao gom bin/, obj/ hoac .git/
- Bai 1 bao gom Bai01.il va Bai01_rebuild.exe theo yeu cau B2/B3
