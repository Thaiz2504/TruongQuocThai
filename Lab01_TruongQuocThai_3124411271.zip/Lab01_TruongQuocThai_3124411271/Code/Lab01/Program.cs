using System;

namespace Lab01;

class Program
{
    static void Main(string[] args)
    {
        int luaChon;

        do
        {
            Console.Clear();

            Console.WriteLine("========== LAB01 - C# ==========");
            Console.WriteLine("1. Bai 01");
            Console.WriteLine("2. Bai 02");
            Console.WriteLine("3. Bai 03");
            Console.WriteLine("4. Bai 04");
            Console.WriteLine("5. Bai 05");
            Console.WriteLine("6. Bai 06");
            Console.WriteLine("7. Bai 07");
            Console.WriteLine("8. Bai 08");
            Console.WriteLine("9. Bai 09");
            Console.WriteLine("10. Bai 10");
            Console.WriteLine("11. Bai 11");
            Console.WriteLine("12. Bai 12");
            Console.WriteLine("13. Bai 13");
            Console.WriteLine("14. Bai 14");
            Console.WriteLine("15. Bai 15");
            Console.WriteLine("16. Bai 16");
            Console.WriteLine("17. Bai 17");
            Console.WriteLine("0. Thoat");
            Console.WriteLine("================================");
            Console.Write("Chon bai: ");

            if (!int.TryParse(Console.ReadLine(), out luaChon))
            {
                Console.WriteLine("Lua chon khong hop le.");
                Console.ReadKey();
                continue;
            }

            Console.Clear();

            switch (luaChon)
            {
                case 1:
                    Bai01.Run();
                    break;
                case 2:
                    Bai02.Run();
                    break;
                case 3:
                    Bai03.Run();
                    break;
                case 4:
                    Bai04.Run();
                    break;
                case 5:
                    Bai05.Run();
                    break;
                case 6:
                    Bai06.Run();
                    break;
                case 7:
                    Bai07.Run();
                    break;
                case 8:
                    Bai08.Run();
                    break;
                case 9:
                    Bai09.Run();
                    break;
                case 10:
                    Bai10.Run();
                    break;
                case 11:
                    Bai11.Run();
                    break;
                case 12:
                    Bai12.Run();
                    break;
                case 13:
                    Bai13.Run();
                    break;
                case 14:
                    Bai14.Run();
                    break;
                case 15:
                    Bai15.Run();
                    break;
                case 16:
                    Bai16.Run();
                    break;
                case 17:
                    Bai17.Run();
                    break;
                case 0:
                    Console.WriteLine("Ket thuc chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le.");
                    break;
            }

            if (luaChon != 0)
            {
                Console.WriteLine();
                Console.WriteLine("Nhan phim bat ky de quay lai menu...");
                Console.ReadKey();
            }

        } while (luaChon != 0);
    }
}