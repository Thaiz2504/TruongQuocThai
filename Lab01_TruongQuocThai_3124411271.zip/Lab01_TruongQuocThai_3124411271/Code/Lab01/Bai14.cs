using System;

namespace Lab01;

public class NhanVien
{
    // Thong tin cua nhan vien
    public string HoTen { get; set; } = "";
    public double MucLuong { get; set; }
    public int SoNgayVang { get; set; }

    // Nhap thong tin nhan vien
    public void Nhap()
    {
        Console.Write("Nhap ho ten nhan vien: ");
        HoTen = Console.ReadLine()!;

        Console.Write("Nhap muc luong: ");
        MucLuong = double.Parse(Console.ReadLine()!);

        Console.Write("Nhap so ngay vang: ");
        SoNgayVang = int.Parse(Console.ReadLine()!);
    }

    // Tinh luong sau khi tru tien vang
    public double TinhLuong()
    {
        return MucLuong - SoNgayVang * 100000;
    }

    // Xuat thong tin va luong thuc nhan
    public void Xuat()
    {
        Console.WriteLine();
        Console.WriteLine("=== THONG TIN NHAN VIEN ===");
        Console.WriteLine($"Ho ten: {HoTen}");
        Console.WriteLine($"Muc luong: {MucLuong:N0} VNĐ");
        Console.WriteLine($"So ngay vang: {SoNgayVang}");
        Console.WriteLine($"Luong thuc nhan: {TinhLuong():N0} VNĐ");
    }
}

public class Bai14
{
    public static void Run()
    {
        NhanVien nhanVien = new NhanVien();

        nhanVien.Nhap();
        nhanVien.Xuat();
    }
}