﻿using System;

namespace Lab01;

public class Bai01
{
    // B1: Nhap ho ten va xuat ho ten ra man hinh
    public static void Run()
    {
        Console.Write("Nhap ho ten: ");
        string hoTen = Console.ReadLine()!;

        Console.WriteLine("Ho ten vua nhap: " + hoTen);
    }
}