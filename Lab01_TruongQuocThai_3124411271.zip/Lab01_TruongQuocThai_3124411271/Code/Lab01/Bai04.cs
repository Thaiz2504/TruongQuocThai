using System;

namespace Lab01;

public class Bai04
{
    // Nhap x, y va kiem tra du lieu co phai so nguyen hay khong
    public static void Run()
    {
        Console.Write("Nhap so nguyen x: ");
        string inputX = Console.ReadLine()!;

        // TryParse giup kiem tra du lieu ma khong lam chuong trinh bi dung
        if (!int.TryParse(inputX, out int x))
        {
            Console.WriteLine("Loi: x khong phai la so nguyen.");
            return;
        }

        Console.Write("Nhap so nguyen y: ");
        string inputY = Console.ReadLine()!;

        if (!int.TryParse(inputY, out int y))
        {
            Console.WriteLine("Loi: y khong phai la so nguyen.");
            return;
        }

        long ketQua = 1;

        // Tinh x^y
        for (int i = 0; i < y; i++)
        {
            ketQua *= x;
        }

        Console.WriteLine($"Ket qua {x} mu {y} la: {ketQua}");
    }
}