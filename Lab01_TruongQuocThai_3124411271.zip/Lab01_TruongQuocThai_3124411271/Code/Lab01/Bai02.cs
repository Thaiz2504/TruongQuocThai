using System;

namespace Lab01;

public class Bai02
{
    // Nhap ho ten va xuat loi chao
    public static void Run()
    {
        Console.Write("Nhap ho ten cua ban: ");
        string hoTen = Console.ReadLine()!;

        Console.WriteLine($"Chao ban {hoTen}!");
    }
}