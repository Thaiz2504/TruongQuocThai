using System;

namespace Lab01;

public class Bai08
{
    // Hoan vi hai so thuc bang tham chieu ref
    public static void HoanVi(ref double x, ref double y)
    {
        double temp = x;
        x = y;
        y = temp;
    }

    public static void Run()
    {
        Console.Write("Nhap x: ");
        double x = double.Parse(Console.ReadLine()!);

        Console.Write("Nhap y: ");
        double y = double.Parse(Console.ReadLine()!);

        Console.WriteLine($"Truoc khi hoan vi: x = {x}, y = {y}");

        HoanVi(ref x, ref y);

        Console.WriteLine($"Sau khi hoan vi: x = {x}, y = {y}");
    }
}