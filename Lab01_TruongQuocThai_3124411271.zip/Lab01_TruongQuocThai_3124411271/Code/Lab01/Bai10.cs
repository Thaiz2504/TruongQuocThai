using System;

namespace Lab01;

public class Bai10
{
    // Kiem tra chuoi co doi xung hay khong
    public static bool LaChuoiDoiXung(string chuoi)
    {
        int trai = 0;
        int phai = chuoi.Length - 1;

        // So sanh cac cap ky tu tu hai dau chuoi
        while (trai < phai)
        {
            if (chuoi[trai] != chuoi[phai])
            {
                return false;
            }

            trai++;
            phai--;
        }

        return true;
    }

    public static void Run()
    {
        Console.Write("Nhap chuoi: ");
        string chuoi = Console.ReadLine()!;

        if (LaChuoiDoiXung(chuoi))
        {
            Console.WriteLine("Chuoi doi xung.");
        }
        else
        {
            Console.WriteLine("Chuoi khong doi xung.");
        }
    }
}