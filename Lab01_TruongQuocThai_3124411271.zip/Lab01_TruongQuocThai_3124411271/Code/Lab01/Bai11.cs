using System;

namespace Lab01;

public class Bai11
{
    // Dao nguoc mot chuoi va tra ve chuoi moi
    public static string DaoChuoi(string chuoi)
    {
        char[] mangKyTu = chuoi.ToCharArray();

        Array.Reverse(mangKyTu);

        return new string(mangKyTu);
    }

    public static void Run()
    {
        Console.Write("Nhap chuoi: ");
        string chuoi = Console.ReadLine()!;

        string chuoiDao = DaoChuoi(chuoi);

        Console.WriteLine($"Chuoi sau khi dao: {chuoiDao}");
    }
}