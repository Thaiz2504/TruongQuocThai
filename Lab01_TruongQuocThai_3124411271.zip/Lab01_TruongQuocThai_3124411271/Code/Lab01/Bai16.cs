using System;

namespace Lab01;

public class Bai16
{
    // Nhap danh sach ho ten cua n nguoi
    public static string[] NhapDanhSach()
    {
        Console.Write("Nhap so luong nguoi n: ");
        int n = int.Parse(Console.ReadLine()!);

        string[] danhSach = new string[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Nhap ho ten nguoi thu {i + 1}: ");
            danhSach[i] = Console.ReadLine()!;
        }

        return danhSach;
    }

    // In danh sach ho ten
    public static void InDanhSach(string[] danhSach)
    {
        for (int i = 0; i < danhSach.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {danhSach[i]}");
        }
    }

    // Sap xep danh sach theo thu tu tang dan cua chuoi
    public static void SapXepTangDan(string[] danhSach)
    {
        Array.Sort(danhSach, StringComparer.CurrentCulture);
    }

    public static void Run()
    {
        string[] danhSach = NhapDanhSach();

        Console.WriteLine();
        Console.WriteLine("Danh sach ban dau:");
        InDanhSach(danhSach);

        SapXepTangDan(danhSach);

        Console.WriteLine();
        Console.WriteLine("Danh sach sau khi sap xep tang dan:");
        InDanhSach(danhSach);
    }
}