using System;

namespace Lab01;

public class Bai17
{
    // Sinh mang hai chieu n x m, gia tri nam trong [10, 100]
    public static int[,] TaoMangNgauNhien(int n, int m)
    {
        Random random = new Random();
        int[,] mang = new int[n, m];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                mang[i, j] = random.Next(10, 101);
            }
        }

        return mang;
    }

    // In mang hai chieu ra man hinh
    public static void InMang(int[,] mang)
    {
        int n = mang.GetLength(0);
        int m = mang.GetLength(1);

        Console.WriteLine("Mang A:");

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                Console.Write($"{mang[i, j],5}");
            }

            Console.WriteLine();
        }
    }

    // Tach mang thanh mang so chan va mang so le bang out
    public static void TachMang(
        int[,] mang,
        out int[] mangChan,
        out int[] mangLe)
    {
        List<int> chan = new List<int>();
        List<int> le = new List<int>();

        int n = mang.GetLength(0);
        int m = mang.GetLength(1);

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (mang[i, j] % 2 == 0)
                {
                    chan.Add(mang[i, j]);
                }
                else
                {
                    le.Add(mang[i, j]);
                }
            }
        }

        mangChan = chan.ToArray();
        mangLe = le.ToArray();
    }

    // In mang mot chieu
    public static void InMangMotChieu(int[] mang)
    {
        foreach (int x in mang)
        {
            Console.Write($"{x} ");
        }

        Console.WriteLine();
    }

    public static void Run()
    {
        Console.Write("Nhap so dong n: ");
        int n = int.Parse(Console.ReadLine()!);

        Console.Write("Nhap so cot m: ");
        int m = int.Parse(Console.ReadLine()!);

        int[,] mang = TaoMangNgauNhien(n, m);

        Console.WriteLine();
        InMang(mang);

        TachMang(
            mang,
            out int[] mangChan,
            out int[] mangLe);

        Console.WriteLine();

        Console.Write("Mang cac so chan: ");
        InMangMotChieu(mangChan);

        Console.Write("Mang cac so le: ");
        InMangMotChieu(mangLe);
    }
}