using System;

namespace Lab01;

public class Bai05
{
    // Chay menu chinh cua Bai 5
    public static void Run()
    {
        double x = 0;
        double y = 0;

        int luaChon;

        do
        {
            Console.WriteLine();
            Console.WriteLine("MENU");
            Console.WriteLine("1. Nhap hai gia tri so thuc cho x, y");
            Console.WriteLine("2. Tinh x^y");
            Console.WriteLine("3. Tinh can bac 2 cua x va y");
            Console.WriteLine("4. Thoat");
            Console.Write("Chon chuc nang: ");

            if (!int.TryParse(Console.ReadLine(), out luaChon))
            {
                Console.WriteLine("Loi: Lua chon phai la so nguyen.");
                continue;
            }

            switch (luaChon)
            {
                case 1:
                    // Su dung ref de cap nhat truc tiep x va y
                    NhapHaiSo(ref x, ref y);
                    break;

                case 2:
                    // Math.Pow tinh luy thua x^y
                    Console.WriteLine(
                        $"Ket qua {x}^{y} = {Math.Pow(x, y)}");
                    break;

                case 3:
                    // Su dung out de tra ve dong thoi can bac hai cua x va y
                    if (TinhCanBacHai(
                            x,
                            y,
                            out double canX,
                            out double canY))
                    {
                        Console.WriteLine(
                            $"Can bac 2 cua {x} = {canX}");
                        Console.WriteLine(
                            $"Can bac 2 cua {y} = {canY}");
                    }
                    else
                    {
                        Console.WriteLine(
                            "Khong the tinh can bac hai cua so am.");
                    }

                    break;

                case 4:
                    Console.WriteLine("Thoat chuong trinh.");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le.");
                    break;
            }

        } while (luaChon != 4);
    }

    // ref: thay doi truc tiep gia tri cua x va y
    private static void NhapHaiSo(ref double x, ref double y)
    {
        Console.Write("Nhap x: ");
        x = double.Parse(Console.ReadLine()!);

        Console.Write("Nhap y: ");
        y = double.Parse(Console.ReadLine()!);
    }

    // out: tra ve hai gia tri can bac hai
    private static bool TinhCanBacHai(
        double x,
        double y,
        out double canX,
        out double canY)
    {
        canX = 0;
        canY = 0;

        // Khong ton tai can bac hai trong tap so thuc doi voi so am
        if (x < 0 || y < 0)
        {
            return false;
        }

        canX = Math.Sqrt(x);
        canY = Math.Sqrt(y);

        return true;
    }
}