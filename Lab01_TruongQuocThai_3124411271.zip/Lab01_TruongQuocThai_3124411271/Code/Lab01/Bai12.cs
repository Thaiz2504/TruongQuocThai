using System;

namespace Lab01;

public class Bai12
{
    // Chuyen chuoi sang chu thuong, chu hoa va dem so tu
    public static void Run()
    {
        Console.Write("Nhap mot chuoi gom nhieu tu: ");
        string chuoi = Console.ReadLine()!;

        string chuoiThuong = chuoi.ToLower();
        string chuoiHoa = chuoi.ToUpper();

        // Tach chuoi theo khoang trang va bo qua phan tu rong
        string[] cacTu = chuoi.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        Console.WriteLine($"Chuoi viet thuong: {chuoiThuong}");
        Console.WriteLine($"Chuoi viet hoa: {chuoiHoa}");
        Console.WriteLine($"So tu trong chuoi: {cacTu.Length}");
    }
}