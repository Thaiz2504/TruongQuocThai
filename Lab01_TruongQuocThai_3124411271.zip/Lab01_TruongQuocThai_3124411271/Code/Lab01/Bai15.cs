using System;

namespace Lab01;

public class Bai15
{
    // Nhap mang n phan tu so nguyen
    public static int[] NhapMang()
    {
        Console.Write("Nhap so luong phan tu n: ");
        int n = int.Parse(Console.ReadLine()!);

        int[] mang = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Nhap phan tu [{i}]: ");
            mang[i] = int.Parse(Console.ReadLine()!);
        }

        return mang;
    }

    // In cac phan tu trong mang
    public static void InMang(int[] mang)
    {
        Console.Write("Mang: ");

        for (int i = 0; i < mang.Length; i++)
        {
            Console.Write(mang[i]);

            if (i < mang.Length - 1)
            {
                Console.Write(" ");
            }
        }

        Console.WriteLine();
    }

    // Tim phan tu lon nhat trong mang
    public static int TimMax(int[] mang)
    {
        int max = mang[0];

        for (int i = 1; i < mang.Length; i++)
        {
            if (mang[i] > max)
            {
                max = mang[i];
            }
        }

        return max;
    }

    // Tim phan tu nho nhat trong mang
    public static int TimMin(int[] mang)
    {
        int min = mang[0];

        for (int i = 1; i < mang.Length; i++)
        {
            if (mang[i] < min)
            {
                min = mang[i];
            }
        }

        return min;
    }

    // Kiem tra mot so co phai so nguyen to hay khong
    public static bool LaSoNguyenTo(int n)
    {
        if (n < 2)
        {
            return false;
        }

        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }

        return true;
    }

    // Tao mang moi chi chua cac so nguyen to
    public static int[] LayMangSoNguyenTo(int[] mang)
    {
        List<int> ketQua = new List<int>();

        foreach (int x in mang)
        {
            if (LaSoNguyenTo(x))
            {
                ketQua.Add(x);
            }
        }

        return ketQua.ToArray();
    }

    public static void Run()
    {
        int[] mang = NhapMang();

        Console.WriteLine();

        InMang(mang);

        Console.WriteLine($"Phan tu lon nhat: {TimMax(mang)}");
        Console.WriteLine($"Phan tu nho nhat: {TimMin(mang)}");

        int[] mangNguyenTo = LayMangSoNguyenTo(mang);

        Console.Write("Mang cac so nguyen to: ");

        if (mangNguyenTo.Length == 0)
        {
            Console.WriteLine("Khong co");
        }
        else
        {
            InMang(mangNguyenTo);
        }
    }
}