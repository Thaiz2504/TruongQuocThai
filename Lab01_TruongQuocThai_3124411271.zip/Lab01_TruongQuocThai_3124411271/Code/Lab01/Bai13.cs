using System;

namespace Lab01;

public class SinhVien
{
    // Thong tin co ban cua sinh vien
    public string MaSinhVien { get; set; } = "";
    public string HoTen { get; set; } = "";
    public string DiaChi { get; set; } = "";
    public int NamThu { get; set; }

    // Nhap thong tin sinh vien
    public void Nhap()
    {
        Console.Write("Nhap ma sinh vien: ");
        MaSinhVien = Console.ReadLine()!;

        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine()!;

        Console.Write("Nhap dia chi: ");
        DiaChi = Console.ReadLine()!;

        Console.Write("Nhap sinh vien nam thu: ");
        NamThu = int.Parse(Console.ReadLine()!);
    }

    // Xuat thong tin sinh vien
    public void Xuat()
    {
        Console.WriteLine();
        Console.WriteLine("=== THONG TIN SINH VIEN ===");
        Console.WriteLine($"Ma sinh vien: {MaSinhVien}");
        Console.WriteLine($"Ho ten: {HoTen}");
        Console.WriteLine($"Dia chi: {DiaChi}");
        Console.WriteLine($"Nam thu: {NamThu}");
    }
}

public class Bai13
{
    // Tao doi tuong SinhVien, sau do nhap va xuat thong tin
    public static void Run()
    {
        SinhVien sinhVien = new SinhVien();

        sinhVien.Nhap();
        sinhVien.Xuat();
    }
}