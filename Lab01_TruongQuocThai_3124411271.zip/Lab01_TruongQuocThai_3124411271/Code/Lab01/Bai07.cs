using System;

namespace Lab01;

public class Bai07
{
    // Kiem tra n co phai la so nguyen to hay khong
    public static bool LaSoNguyenTo(int n)
    {
        // So nho hon 2 khong phai so nguyen to
        if (n < 2)
        {
            return false;
        }

        // Chi can kiem tra cac uoc tu 2 den can bac hai cua n
        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }

        return true;
    }

    public static void Run()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine()!);

        if (LaSoNguyenTo(n))
        {
            Console.WriteLine($"{n} la so nguyen to.");
        }
        else
        {
            Console.WriteLine($"{n} khong phai la so nguyen to.");
        }
    }
}