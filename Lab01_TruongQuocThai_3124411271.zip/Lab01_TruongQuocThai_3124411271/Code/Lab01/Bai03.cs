using System;

namespace Lab01;

public class Bai03
{
    // Nhap hai so nguyen x, y va tinh x^y
    public static void Run()
    {
        Console.Write("Nhap so nguyen x: ");
        int x = int.Parse(Console.ReadLine()!);

        Console.Write("Nhap so nguyen y: ");
        int y = int.Parse(Console.ReadLine()!);

        long ketQua = 1;

        // Nhan x voi chinh no y lan
        for (int i = 0; i < y; i++)
        {
            ketQua *= x;
        }

        Console.WriteLine($"Ket qua {x} mu {y} la: {ketQua}");
    }
}