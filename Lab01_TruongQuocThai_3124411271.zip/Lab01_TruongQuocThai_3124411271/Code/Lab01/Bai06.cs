using System;

namespace Lab01;

public class Bai06
{
    // Tra ve gia tri lon nhat cua ba so nguyen
    public static int TimMax(int a, int b, int c)
    {
        int max = a;

        if (b > max)
        {
            max = b;
        }

        if (c > max)
        {
            max = c;
        }

        return max;
    }

    public static void Run()
    {
        Console.Write("Nhap so nguyen a: ");
        int a = int.Parse(Console.ReadLine()!);

        Console.Write("Nhap so nguyen b: ");
        int b = int.Parse(Console.ReadLine()!);

        Console.Write("Nhap so nguyen c: ");
        int c = int.Parse(Console.ReadLine()!);

        int max = TimMax(a, b, c);

        Console.WriteLine($"Gia tri lon nhat la: {max}");
    }
}