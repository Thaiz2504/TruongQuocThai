using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Bai08;

public partial class frmBai08 : Form
{
    private readonly List<Button> danhSachGhe = new();

    private readonly bool[] gheDaBan = new bool[15];

    private readonly bool[] gheDangChon = new bool[15];

    private readonly int[] giaVe =
    {
        1000, 1000, 1000, 1000, 1000,
        1500, 1500, 1500, 1500, 1500,
        2000, 2000, 2000, 2000, 2000
    };

    public frmBai08()
    {
        InitializeComponent();

        TaoSoDoGhe();

        CapNhatThanhTien();
    }

    private void TaoSoDoGhe()
    {
        danhSachGhe.Clear();

        for (int i = 0; i < 15; i++)
        {
            Button btnGhe = new Button();

            btnGhe.Width = 80;
            btnGhe.Height = 50;

            int hang = i / 5;
            int cot = i % 5;

            btnGhe.Left = 20 + cot * 95;
            btnGhe.Top = 20 + hang * 75;

            btnGhe.Text = (i + 1).ToString();

            btnGhe.Tag = i;

            btnGhe.BackColor = Color.White;

            btnGhe.Click += btnGhe_Click;

            pnlGhe.Controls.Add(btnGhe);

            danhSachGhe.Add(btnGhe);
        }
    }

    private void btnGhe_Click(
        object? sender,
        EventArgs e)
    {
        if (sender is not Button btn)
        {
            return;
        }

        int viTri = (int)btn.Tag!;

        // Ghế đã bán
        if (gheDaBan[viTri])
        {
            MessageBox.Show(
                "Ghế này đã được bán!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            return;
        }

        // Ghế đang chọn
        if (gheDangChon[viTri])
        {
            gheDangChon[viTri] = false;

            btn.BackColor = Color.White;
        }
        else
        {
            gheDangChon[viTri] = true;

            btn.BackColor = Color.Blue;
        }

        CapNhatThanhTien();
    }

    private void CapNhatThanhTien()
    {
        int tongTien = 0;

        for (int i = 0; i < 15; i++)
        {
            if (gheDangChon[i])
            {
                tongTien += giaVe[i];
            }
        }

        lblThanhTien.Text =
            tongTien.ToString("N0");
    }

    private void btnChon_Click(
        object? sender,
        EventArgs e)
    {
        bool coGhe = false;

        for (int i = 0; i < 15; i++)
        {
            if (gheDangChon[i])
            {
                coGhe = true;

                gheDangChon[i] = false;
                gheDaBan[i] = true;

                danhSachGhe[i].BackColor =
                    Color.Yellow;
            }
        }

        if (!coGhe)
        {
            MessageBox.Show(
                "Bạn chưa chọn ghế nào!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            return;
        }

        CapNhatThanhTien();
    }

    private void btnHuyBo_Click(
        object? sender,
        EventArgs e)
    {
        for (int i = 0; i < 15; i++)
        {
            if (gheDangChon[i])
            {
                gheDangChon[i] = false;

                danhSachGhe[i].BackColor =
                    Color.White;
            }
        }

        lblThanhTien.Text = "0";
    }

    private void btnThoat_Click(
        object? sender,
        EventArgs e)
    {
        Close();
    }

    private void frmBai08_FormClosing(
        object? sender,
        FormClosingEventArgs e)
    {
        DialogResult result = MessageBox.Show(
            "Bạn có chắc muốn thoát không?",
            "Xác nhận",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (result == DialogResult.No)
        {
            e.Cancel = true;
        }
    }
}