using System;
using System.Windows.Forms;

namespace Bai09;

public partial class frmBai09 : Form
{
    // Tổng số khách đã thanh toán trong ngày
    private int tongSoKhach = 0;

    // Tổng số tiền đã thanh toán trong ngày
    private decimal tongTienThanhToan = 0;

    // Tiền của nhóm khách hiện tại sau khi bấm Tính tiền
    private decimal tienHienTai = 0;

    public frmBai09()
    {
        InitializeComponent();
    }

    private void frmBai09_Load(
        object? sender,
        EventArgs e)
    {
        // Khi Form mở:
        // - Đặt con trỏ vào ô tên khách hàng
        // - Các nút xử lý chưa được phép sử dụng
        txtTenKhach.Focus();

        btnTinhTien.Enabled = false;
        btnNhapLai.Enabled = false;
        btnThanhToan.Enabled = false;

        CapNhatTongKet();
    }

    private void txtSoKhach_KeyPress(
        object? sender,
        KeyPressEventArgs e)
    {
        // Chỉ cho phép nhập chữ số và Backspace
        if (!char.IsDigit(e.KeyChar) &&
            e.KeyChar != '\b')
        {
            e.Handled = true;
        }
    }

    private void Input_Changed(
        object? sender,
        EventArgs e)
    {
        CapNhatTrangThaiNut();
    }

    private void LuaChon_Changed(
        object? sender,
        EventArgs e)
    {
        CapNhatTrangThaiNut();
    }

    private bool DuLieuDayDu()
    {
        // Kiểm tra tên khách hàng
        if (string.IsNullOrWhiteSpace(txtTenKhach.Text))
        {
            return false;
        }

        // Kiểm tra số khách
        if (!int.TryParse(
                txtSoKhach.Text,
                out int soKhach) ||
            soKhach <= 0)
        {
            return false;
        }

        // Phải chọn một loại cafe
        if (!CoCafeDuocChon())
        {
            return false;
        }

        // Phải chọn một loại thức ăn
        if (!CoThucAnDuocChon())
        {
            return false;
        }

        return true;
    }

    private bool CoCafeDuocChon()
    {
        return rdoCafeDen.Checked ||
               rdoCafeDa.Checked ||
               rdoCafeSua.Checked ||
               rdoCafeSuaDa.Checked ||
               rdoCafeKem.Checked;
    }

    private bool CoThucAnDuocChon()
    {
        return rdoBanhMiTrung.Checked ||
               rdoBanhMiCa.Checked ||
               rdoMiTomTrung.Checked ||
               rdoMiXaoBo.Checked ||
               rdoMiCay.Checked;
    }

    private void CapNhatTrangThaiNut()
    {
        // Khi đang nhập một nhóm khách mới,
        // chỉ Tính tiền được bật khi đủ dữ liệu.
        if (!btnThanhToan.Enabled)
        {
            btnTinhTien.Enabled = DuLieuDayDu();
        }
    }

    private decimal LayGiaCafe()
    {
        if (rdoCafeDen.Checked)
            return 20000;

        if (rdoCafeDa.Checked)
            return 25000;

        if (rdoCafeSua.Checked)
            return 25000;

        if (rdoCafeSuaDa.Checked)
            return 30000;

        if (rdoCafeKem.Checked)
            return 35000;

        return 0;
    }

    private string LayTenCafe()
    {
        if (rdoCafeDen.Checked)
            return "Cafe đen";

        if (rdoCafeDa.Checked)
            return "Cafe đá";

        if (rdoCafeSua.Checked)
            return "Cafe sữa";

        if (rdoCafeSuaDa.Checked)
            return "Cafe sữa đá";

        if (rdoCafeKem.Checked)
            return "Cafe kem";

        return "";
    }

    private decimal LayGiaThucAn()
    {
        if (rdoBanhMiTrung.Checked)
            return 15000;

        if (rdoBanhMiCa.Checked)
            return 15000;

        if (rdoMiTomTrung.Checked)
            return 20000;

        if (rdoMiXaoBo.Checked)
            return 30000;

        if (rdoMiCay.Checked)
            return 50000;

        return 0;
    }

    private string LayTenThucAn()
    {
        if (rdoBanhMiTrung.Checked)
            return "Bánh mỳ trứng";

        if (rdoBanhMiCa.Checked)
            return "Bánh mỳ cá";

        if (rdoMiTomTrung.Checked)
            return "Mỳ tôm trứng";

        if (rdoMiXaoBo.Checked)
            return "Mỳ xào bò";

        if (rdoMiCay.Checked)
            return "Mỳ cay";

        return "";
    }

    private decimal TinhTien()
    {
        int soKhach = int.Parse(txtSoKhach.Text);

        decimal tienMotNguoi =
            LayGiaCafe() +
            LayGiaThucAn();

        decimal tongTien =
            tienMotNguoi * soKhach;

        // Sinh viên được giảm 20%
        if (chkSinhVien.Checked)
        {
            tongTien *= 0.8m;
        }

        return tongTien;
    }

    private void btnTinhTien_Click(
        object? sender,
        EventArgs e)
    {
        if (!DuLieuDayDu())
        {
            MessageBox.Show(
                "Vui lòng nhập đầy đủ thông tin!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            return;
        }

        int soKhach = int.Parse(txtSoKhach.Text);

        tienHienTai = TinhTien();

        string loaiKhach = chkSinhVien.Checked
            ? "Sinh viên - giảm 20%"
            : "Khách thường";

        string thongTin =
            "Tên khách hàng: " + txtTenKhach.Text + "\n" +
            "Số khách: " + soKhach + "\n" +
            "Cafe: " + LayTenCafe() + "\n" +
            "Thức ăn: " + LayTenThucAn() + "\n" +
            "Đối tượng: " + loaiKhach + "\n" +
            "Thành tiền: " +
            tienHienTai.ToString("N0") + "đ";

        MessageBox.Show(
            thongTin,
            "Thông tin thanh toán",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);

        // Cho phép nhập lại hoặc thanh toán
        btnNhapLai.Enabled = true;
        btnThanhToan.Enabled = true;

        // Không tính lại lần nữa cho đến khi nhập nhóm mới
        btnTinhTien.Enabled = false;
    }

    private void btnNhapLai_Click(
        object? sender,
        EventArgs e)
    {
        // Xóa thông tin nhóm khách hiện tại
        txtTenKhach.Clear();
        txtSoKhach.Clear();

        rdoCafeDen.Checked = false;
        rdoCafeDa.Checked = false;
        rdoCafeSua.Checked = false;
        rdoCafeSuaDa.Checked = false;
        rdoCafeKem.Checked = false;

        rdoBanhMiTrung.Checked = false;
        rdoBanhMiCa.Checked = false;
        rdoMiTomTrung.Checked = false;
        rdoMiXaoBo.Checked = false;
        rdoMiCay.Checked = false;

        chkSinhVien.Checked = false;

        errorProvider1.Clear();

        tienHienTai = 0;

        btnTinhTien.Enabled = false;
        btnNhapLai.Enabled = false;
        btnThanhToan.Enabled = false;

        txtTenKhach.Focus();
    }

    private void btnThanhToan_Click(
        object? sender,
        EventArgs e)
    {
        int soKhach = int.Parse(txtSoKhach.Text);

        // Cộng dồn số khách và tiền thanh toán
        tongSoKhach += soKhach;
        tongTienThanhToan += tienHienTai;

        CapNhatTongKet();

        // Nhóm hiện tại đã thanh toán
        btnThanhToan.Enabled = false;

        MessageBox.Show(
            "Thanh toán thành công!",
            "Thông báo",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private void CapNhatTongKet()
    {
        txtTongKhach.Text =
            tongSoKhach.ToString();

        txtTongTien.Text =
            tongTienThanhToan.ToString("N0") + "đ";
    }

    private void btnThoat_Click(
        object? sender,
        EventArgs e)
    {
        Close();
    }

    private void frmBai09_FormClosing(
        object? sender,
        FormClosingEventArgs e)
    {
        DialogResult result = MessageBox.Show(
            "Bạn có chắc muốn thoát không?",
            "Xác nhận",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (result == DialogResult.No)
        {
            e.Cancel = true;
        }
    }
}