﻿#nullable enable

namespace Bai11;

partial class frmBai11
{
    private System.ComponentModel.IContainer? components = null;

    private Label lblTieuDe = null!;
    private Label lblTenKhach = null!;
    private Label lblDiaChi = null!;
    private Label lblSoNgay = null!;

    private TextBox txtTenKhach = null!;
    private TextBox txtDiaChi = null!;
    private TextBox txtSoNgay = null!;

    private GroupBox grpLoaiPhong = null!;
    private RadioButton rdoPhongDon = null!;
    private RadioButton rdoPhongDoi = null!;
    private RadioButton rdoPhongBa = null!;

    private GroupBox grpTienNghi = null!;
    private CheckBox chkTivi = null!;
    private CheckBox chkInternet = null!;
    private CheckBox chkMayNuocNong = null!;

    private GroupBox grpDichVu = null!;
    private CheckBox chkKaraoke = null!;
    private CheckBox chkAnSang = null!;

    private GroupBox grpThongTinTongKet = null!;
    private Label lblThanhTienText = null!;
    private TextBox txtThanhTien = null!;
    private Label lblSoLuotNguoiText = null!;
    private TextBox txtSoLuotNguoi = null!;
    private Label lblTongSoTienText = null!;
    private TextBox txtTongSoTien = null!;

    private Button btnThanhToan = null!;
    private Button btnNhapMoi = null!;
    private Button btnTongKet = null!;
    private Button btnThoat = null!;

    private ErrorProvider errorProvider1 = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
            components.Dispose();

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        lblTieuDe = new Label();
        lblTenKhach = new Label();
        lblDiaChi = new Label();
        lblSoNgay = new Label();

        txtTenKhach = new TextBox();
        txtDiaChi = new TextBox();
        txtSoNgay = new TextBox();

        grpLoaiPhong = new GroupBox();
        rdoPhongDon = new RadioButton();
        rdoPhongDoi = new RadioButton();
        rdoPhongBa = new RadioButton();

        grpTienNghi = new GroupBox();
        chkTivi = new CheckBox();
        chkInternet = new CheckBox();
        chkMayNuocNong = new CheckBox();

        grpDichVu = new GroupBox();
        chkKaraoke = new CheckBox();
        chkAnSang = new CheckBox();

        grpThongTinTongKet = new GroupBox();
        lblThanhTienText = new Label();
        txtThanhTien = new TextBox();
        lblSoLuotNguoiText = new Label();
        txtSoLuotNguoi = new TextBox();
        lblTongSoTienText = new Label();
        txtTongSoTien = new TextBox();

        btnThanhToan = new Button();
        btnNhapMoi = new Button();
        btnTongKet = new Button();
        btnThoat = new Button();

        errorProvider1 = new ErrorProvider(components);

        SuspendLayout();

        // Tiêu đề
        lblTieuDe.AutoSize = true;
        lblTieuDe.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTieuDe.Location = new Point(175, 12);
        lblTieuDe.Text = "KHÁCH SẠN THANH THANH - TRẢ PHÒNG";

        // Thông tin khách
        lblTenKhach.AutoSize = true;
        lblTenKhach.Location = new Point(25, 60);
        lblTenKhach.Text = "Họ và tên:";

        txtTenKhach.Location = new Point(100, 55);
        txtTenKhach.Name = "txtTenKhach";
        txtTenKhach.Size = new Size(185, 23);
        txtTenKhach.TabIndex = 0;
        txtTenKhach.TextChanged += Input_Changed;

        lblDiaChi.AutoSize = true;
        lblDiaChi.Location = new Point(25, 95);
        lblDiaChi.Text = "Địa chỉ:";

        txtDiaChi.Location = new Point(100, 90);
        txtDiaChi.Name = "txtDiaChi";
        txtDiaChi.Size = new Size(185, 23);
        txtDiaChi.TabIndex = 1;
        txtDiaChi.TextChanged += Input_Changed;

        lblSoNgay.AutoSize = true;
        lblSoNgay.Location = new Point(25, 130);
        lblSoNgay.Text = "Số ngày ở:";

        txtSoNgay.Location = new Point(100, 125);
        txtSoNgay.Name = "txtSoNgay";
        txtSoNgay.Size = new Size(80, 23);
        txtSoNgay.TabIndex = 2;
        txtSoNgay.KeyPress += txtSoNgay_KeyPress;
        txtSoNgay.TextChanged += Input_Changed;

        // Loại phòng
        grpLoaiPhong.Location = new Point(20, 165);
        grpLoaiPhong.Name = "grpLoaiPhong";
        grpLoaiPhong.Size = new Size(145, 125);
        grpLoaiPhong.Text = "Loại phòng";

        rdoPhongDon.AutoSize = true;
        rdoPhongDon.Location = new Point(12, 25);
        rdoPhongDon.Text = "Phòng đơn";
        rdoPhongDon.CheckedChanged += LuaChon_Changed;

        rdoPhongDoi.AutoSize = true;
        rdoPhongDoi.Location = new Point(12, 52);
        rdoPhongDoi.Text = "Phòng đôi";
        rdoPhongDoi.CheckedChanged += LuaChon_Changed;

        rdoPhongBa.AutoSize = true;
        rdoPhongBa.Location = new Point(12, 79);
        rdoPhongBa.Text = "Phòng ba";
        rdoPhongBa.CheckedChanged += LuaChon_Changed;

        grpLoaiPhong.Controls.Add(rdoPhongDon);
        grpLoaiPhong.Controls.Add(rdoPhongDoi);
        grpLoaiPhong.Controls.Add(rdoPhongBa);

        // Tiện nghi
        grpTienNghi.Location = new Point(175, 165);
        grpTienNghi.Name = "grpTienNghi";
        grpTienNghi.Size = new Size(135, 125);
        grpTienNghi.Text = "Tiện nghi";

        chkTivi.AutoSize = true;
        chkTivi.Location = new Point(10, 25);
        chkTivi.Text = "Tivi";
        chkTivi.CheckedChanged += LuaChon_Changed;

        chkInternet.AutoSize = true;
        chkInternet.Location = new Point(10, 52);
        chkInternet.Text = "Internet";
        chkInternet.CheckedChanged += LuaChon_Changed;

        chkMayNuocNong.AutoSize = true;
        chkMayNuocNong.Location = new Point(10, 79);
        chkMayNuocNong.Text = "Máy nước nóng";
        chkMayNuocNong.CheckedChanged += LuaChon_Changed;

        grpTienNghi.Controls.Add(chkTivi);
        grpTienNghi.Controls.Add(chkInternet);
        grpTienNghi.Controls.Add(chkMayNuocNong);

        // Dịch vụ
        grpDichVu.Location = new Point(20, 300);
        grpDichVu.Name = "grpDichVu";
        grpDichVu.Size = new Size(290, 75);
        grpDichVu.Text = "Dịch vụ";

        chkKaraoke.AutoSize = true;
        chkKaraoke.Location = new Point(12, 30);
        chkKaraoke.Text = "Karaoke";
        chkKaraoke.CheckedChanged += LuaChon_Changed;

        chkAnSang.AutoSize = true;
        chkAnSang.Location = new Point(145, 30);
        chkAnSang.Text = "Ăn sáng";
        chkAnSang.CheckedChanged += LuaChon_Changed;

        grpDichVu.Controls.Add(chkKaraoke);
        grpDichVu.Controls.Add(chkAnSang);

        // Thông tin tổng kết
        grpThongTinTongKet.Location = new Point(330, 45);
        grpThongTinTongKet.Name = "grpThongTinTongKet";
        grpThongTinTongKet.Size = new Size(325, 330);
        grpThongTinTongKet.Text = "Thông tin tổng kết";

        // Thành tiền
        lblThanhTienText.AutoSize = true;
        lblThanhTienText.Location = new Point(18, 75);
        lblThanhTienText.Text = "Thành tiền:";

        txtThanhTien.Location = new Point(105, 70);
        txtThanhTien.Name = "txtThanhTien";
        txtThanhTien.ReadOnly = true;
        txtThanhTien.Size = new Size(195, 23);

        // Tổng số lượt người
        lblSoLuotNguoiText.AutoSize = true;
        lblSoLuotNguoiText.Location = new Point(18, 185);
        lblSoLuotNguoiText.Text = "Số lượt người:";

        txtSoLuotNguoi.Location = new Point(105, 180);
        txtSoLuotNguoi.Name = "txtSoLuotNguoi";
        txtSoLuotNguoi.ReadOnly = true;
        txtSoLuotNguoi.Size = new Size(195, 23);

        // Tổng số tiền
        lblTongSoTienText.AutoSize = true;
        lblTongSoTienText.Location = new Point(18, 225);
        lblTongSoTienText.Text = "Tổng số tiền:";

        txtTongSoTien.Location = new Point(105, 220);
        txtTongSoTien.Name = "txtTongSoTien";
        txtTongSoTien.ReadOnly = true;
        txtTongSoTien.Size = new Size(195, 23);

        // Các nút bên phải theo mẫu
        btnThanhToan.Location = new Point(18, 30);
        btnThanhToan.Name = "btnThanhToan";
        btnThanhToan.Size = new Size(90, 32);
        btnThanhToan.Text = "Thanh toán";
        btnThanhToan.Enabled = false;
        btnThanhToan.Click += btnThanhToan_Click;

        btnNhapMoi.Location = new Point(115, 30);
        btnNhapMoi.Name = "btnNhapMoi";
        btnNhapMoi.Size = new Size(90, 32);
        btnNhapMoi.Text = "Nhập mới";
        btnNhapMoi.Enabled = false;
        btnNhapMoi.Click += btnNhapMoi_Click;

        btnTongKet.Location = new Point(18, 125);
        btnTongKet.Name = "btnTongKet";
        btnTongKet.Size = new Size(90, 32);
        btnTongKet.Text = "Tổng kết";
        btnTongKet.Enabled = false;
        btnTongKet.Click += btnTongKet_Click;

        btnThoat.Location = new Point(18, 265);
        btnThoat.Name = "btnThoat";
        btnThoat.Size = new Size(90, 32);
        btnThoat.Text = "Thoát";
        btnThoat.Click += btnThoat_Click;

        grpThongTinTongKet.Controls.Add(btnThanhToan);
        grpThongTinTongKet.Controls.Add(btnNhapMoi);
        grpThongTinTongKet.Controls.Add(lblThanhTienText);
        grpThongTinTongKet.Controls.Add(txtThanhTien);
        grpThongTinTongKet.Controls.Add(btnTongKet);
        grpThongTinTongKet.Controls.Add(lblSoLuotNguoiText);
        grpThongTinTongKet.Controls.Add(txtSoLuotNguoi);
        grpThongTinTongKet.Controls.Add(lblTongSoTienText);
        grpThongTinTongKet.Controls.Add(txtTongSoTien);
        grpThongTinTongKet.Controls.Add(btnThoat);

        errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;

        // Form
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(680, 405);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Name = "frmBai11";
        Text = "Lab04 - Bài tập về nhà: Khách sạn Thanh Thanh";

        Controls.Add(lblTieuDe);
        Controls.Add(lblTenKhach);
        Controls.Add(txtTenKhach);
        Controls.Add(lblDiaChi);
        Controls.Add(txtDiaChi);
        Controls.Add(lblSoNgay);
        Controls.Add(txtSoNgay);
        Controls.Add(grpLoaiPhong);
        Controls.Add(grpTienNghi);
        Controls.Add(grpDichVu);
        Controls.Add(grpThongTinTongKet);

        Load += frmBai11_Load;
        FormClosing += frmBai11_FormClosing;

        ResumeLayout(false);
        PerformLayout();
    }
}
