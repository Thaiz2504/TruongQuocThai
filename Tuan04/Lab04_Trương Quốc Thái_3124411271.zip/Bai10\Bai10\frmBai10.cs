using System;
using System.Globalization;
using System.Windows.Forms;

namespace Bai10;

public partial class frmBai10 : Form
{
    private double soThuNhat = 0;

    private string phepToan = "";

    private bool dangNhapSoMoi = true;

    public frmBai10()
    {
        InitializeComponent();

        txtManHinh.Text = "0";
    }

    // Xử lý các nút số 0-9
    private void btnSo_Click(
        object? sender,
        EventArgs e)
    {
        if (sender is not Button button)
        {
            return;
        }

        if (dangNhapSoMoi ||
            txtManHinh.Text == "0")
        {
            txtManHinh.Text =
                button.Text;

            dangNhapSoMoi = false;
        }
        else
        {
            txtManHinh.Text +=
                button.Text;
        }
    }

    // Xử lý các phép + - x /
    private void btnPhepToan_Click(
        object? sender,
        EventArgs e)
    {
        if (sender is not Button button)
        {
            return;
        }

        if (!double.TryParse(
                txtManHinh.Text,
                NumberStyles.Float,
                CultureInfo.CurrentCulture,
                out soThuNhat))
        {
            MessageBox.Show(
                "Giá trị không hợp lệ!",
                "Lỗi");

            return;
        }

        phepToan = button.Text;

        dangNhapSoMoi = true;
    }

    // Nút dấu chấm
    private void btnCham_Click(
        object? sender,
        EventArgs e)
    {
        if (dangNhapSoMoi)
        {
            txtManHinh.Text = "0.";
            dangNhapSoMoi = false;
            return;
        }

        if (!txtManHinh.Text.Contains("."))
        {
            txtManHinh.Text += ".";
        }
    }

    // Nút =
    private void btnBang_Click(
        object? sender,
        EventArgs e)
    {
        if (!double.TryParse(
                txtManHinh.Text,
                NumberStyles.Float,
                CultureInfo.CurrentCulture,
                out double soThuHai))
        {
            MessageBox.Show(
                "Giá trị không hợp lệ!",
                "Lỗi");

            return;
        }

        double ketQua = 0;

        switch (phepToan)
        {
            case "+":
                ketQua =
                    soThuNhat +
                    soThuHai;
                break;

            case "-":
                ketQua =
                    soThuNhat -
                    soThuHai;
                break;

            case "x":
                ketQua =
                    soThuNhat *
                    soThuHai;
                break;

            case "/":

                if (soThuHai == 0)
                {
                    MessageBox.Show(
                        "Không thể chia cho 0!",
                        "Lỗi",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }

                ketQua =
                    soThuNhat /
                    soThuHai;

                break;

            default:
                return;
        }

        txtManHinh.Text =
            ketQua.ToString(
                CultureInfo.CurrentCulture);

        phepToan = "";

        dangNhapSoMoi = true;
    }

    // Nút C / Xóa
    private void btnXoa_Click(
        object? sender,
        EventArgs e)
    {
        soThuNhat = 0;

        phepToan = "";

        dangNhapSoMoi = true;

        txtManHinh.Text = "0";
    }

    // Xác nhận thoát
    private void frmBai10_FormClosing(
        object? sender,
        FormClosingEventArgs e)
    {
        DialogResult result =
            MessageBox.Show(
                "Bạn có chắc muốn thoát không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

        if (result == DialogResult.No)
        {
            e.Cancel = true;
        }
    }
}