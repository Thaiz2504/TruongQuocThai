using System;
using System.Windows.Forms;

namespace Bai11;

public partial class frmBai11 : Form
{
    // Tổng số lượt khách đã thanh toán trong ngày.
    private int tongSoLuotNguoi = 0;

    // Tổng số tiền đã thanh toán trong ngày.
    private decimal tongSoTien = 0;

    // Thành tiền của khách hiện tại.
    private decimal thanhTienHienTai = 0;

    public frmBai11()
    {
        InitializeComponent();
    }

    private void frmBai11_Load(
        object? sender,
        EventArgs e)
    {
        // Trạng thái ban đầu theo đề.
        txtTenKhach.Focus();

        btnThanhToan.Enabled = false;
        btnNhapMoi.Enabled = false;
        btnTongKet.Enabled = false;

        txtThanhTien.Clear();
        txtSoLuotNguoi.Clear();
        txtTongSoTien.Clear();
    }

    private void Input_Changed(
        object? sender,
        EventArgs e)
    {
        CapNhatTrangThaiThanhToan();
    }

    private void LuaChon_Changed(
        object? sender,
        EventArgs e)
    {
        CapNhatTrangThaiThanhToan();
    }

    private void txtSoNgay_KeyPress(
        object? sender,
        KeyPressEventArgs e)
    {
        // Chỉ cho nhập chữ số và Backspace.
        if (!char.IsDigit(e.KeyChar) &&
            e.KeyChar != '\b')
        {
            e.Handled = true;
        }
    }

    private bool DuLieuHopLe()
    {
        errorProvider1.SetError(txtTenKhach, "");
        errorProvider1.SetError(txtDiaChi, "");
        errorProvider1.SetError(txtSoNgay, "");

        bool hopLe = true;

        // Tên khách bắt buộc phải nhập.
        if (string.IsNullOrWhiteSpace(txtTenKhach.Text))
        {
            errorProvider1.SetError(
                txtTenKhach,
                "Tên khách không được để trống.");

            hopLe = false;
        }

        // Địa chỉ phải được nhập đầy đủ.
        if (string.IsNullOrWhiteSpace(txtDiaChi.Text))
        {
            errorProvider1.SetError(
                txtDiaChi,
                "Địa chỉ không được để trống.");

            hopLe = false;
        }

        // Số ngày ở phải là số nguyên dương.
        if (!int.TryParse(
                txtSoNgay.Text,
                out int soNgay) ||
            soNgay <= 0)
        {
            errorProvider1.SetError(
                txtSoNgay,
                "Số ngày ở phải là số nguyên dương.");

            hopLe = false;
        }

        // Phải chọn một loại phòng.
        if (!CoPhongDuocChon())
        {
            hopLe = false;
        }

        return hopLe;
    }

    private bool CoPhongDuocChon()
    {
        return rdoPhongDon.Checked ||
               rdoPhongDoi.Checked ||
               rdoPhongBa.Checked;
    }

    private void CapNhatTrangThaiThanhToan()
    {
        // Sau khi đã thanh toán khách hiện tại,
        // không cho thanh toán lại cùng một khách.
        if (!btnNhapMoi.Enabled)
        {
            btnThanhToan.Enabled = DuLieuHopLe();
        }
    }

    private decimal LayGiaPhong()
    {
        if (rdoPhongDon.Checked)
            return 300000m;

        if (rdoPhongDoi.Checked)
            return 350000m;

        if (rdoPhongBa.Checked)
            return 400000m;

        return 0m;
    }

    private decimal TinhTien()
    {
        int soNgay = int.Parse(txtSoNgay.Text);

        // Tiền phòng = đơn giá phòng × số ngày.
        decimal tienPhong =
            LayGiaPhong() * soNgay;

        // Mỗi tiện nghi cộng thêm 10.000đ.
        int soLoaiTienNghi = 0;

        if (chkTivi.Checked)
            soLoaiTienNghi++;

        if (chkInternet.Checked)
            soLoaiTienNghi++;

        if (chkMayNuocNong.Checked)
            soLoaiTienNghi++;

        decimal tienTienNghi =
            soLoaiTienNghi * 10000m;

        // Karaoke: 50.000đ.
        decimal tienKaraoke =
            chkKaraoke.Checked
                ? 50000m
                : 0m;

        // Ăn sáng: 15.000đ/ngày.
        decimal tienAnSang =
            chkAnSang.Checked
                ? 15000m * soNgay
                : 0m;

        return tienPhong
             + tienTienNghi
             + tienKaraoke
             + tienAnSang;
    }

    private void btnThanhToan_Click(
        object? sender,
        EventArgs e)
    {
        if (!DuLieuHopLe())
        {
            MessageBox.Show(
                "Vui lòng nhập đầy đủ thông tin!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            return;
        }

        // Tính tiền cho khách hiện tại.
        thanhTienHienTai = TinhTien();

        // Hiển thị thành tiền trên Form.
        txtThanhTien.Text =
            thanhTienHienTai.ToString("N0") + "đ";

        // Lưu tổng số lượt khách và tổng tiền trong ngày.
        tongSoLuotNguoi++;
        tongSoTien += thanhTienHienTai;

        // Sau thanh toán, cho phép nhập khách mới
        // hoặc xem tổng kết.
        btnNhapMoi.Enabled = true;
        btnTongKet.Enabled = true;

        // Không thanh toán lại cùng khách hiện tại.
        btnThanhToan.Enabled = false;
    }

    private void btnNhapMoi_Click(
        object? sender,
        EventArgs e)
    {
        // Đưa thông tin khách hiện tại về trạng thái ban đầu.
        txtTenKhach.Clear();
        txtDiaChi.Clear();
        txtSoNgay.Clear();

        rdoPhongDon.Checked = false;
        rdoPhongDoi.Checked = false;
        rdoPhongBa.Checked = false;

        chkTivi.Checked = false;
        chkInternet.Checked = false;
        chkMayNuocNong.Checked = false;

        chkKaraoke.Checked = false;
        chkAnSang.Checked = false;

        txtThanhTien.Clear();

        thanhTienHienTai = 0m;

        errorProvider1.Clear();

        btnThanhToan.Enabled = false;
        btnNhapMoi.Enabled = false;

        // Nếu còn dữ liệu tổng trong ngày,
        // vẫn cho phép bấm Tổng kết.
        btnTongKet.Enabled = tongSoLuotNguoi > 0;

        txtTenKhach.Focus();
    }

    private void btnTongKet_Click(
        object? sender,
        EventArgs e)
    {
        // Ghi thông tin tổng kết vào các ô tương ứng.
        txtSoLuotNguoi.Text =
            tongSoLuotNguoi.ToString();

        txtTongSoTien.Text =
            tongSoTien.ToString("N0") + "đ";

        // Kết thúc lần tổng kết trong ngày
        // và đưa bộ đếm về 0 theo yêu cầu đề.
        tongSoLuotNguoi = 0;
        tongSoTien = 0m;

        btnTongKet.Enabled = false;
    }

    private void btnThoat_Click(
        object? sender,
        EventArgs e)
    {
        Close();
    }

    private void frmBai11_FormClosing(
        object? sender,
        FormClosingEventArgs e)
    {
        DialogResult result = MessageBox.Show(
            "Bạn có chắc chắn thoát khỏi chương trình hay không?",
            "Xác nhận",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (result == DialogResult.No)
        {
            e.Cancel = true;
        }
    }
}
