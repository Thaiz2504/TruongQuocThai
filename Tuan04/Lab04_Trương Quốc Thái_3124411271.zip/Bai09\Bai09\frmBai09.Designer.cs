﻿#nullable enable

namespace Bai09;

partial class frmBai09
{
    private System.ComponentModel.IContainer? components = null;

    private Label lblTenKhach = null!;
    private Label lblSoKhach = null!;
    private Label lblCafe = null!;
    private Label lblThucAn = null!;
    private Label lblTongKhach = null!;
    private Label lblTongTien = null!;

    private TextBox txtTenKhach = null!;
    private TextBox txtSoKhach = null!;
    private TextBox txtTongKhach = null!;
    private TextBox txtTongTien = null!;

    private GroupBox grpCafe = null!;
    private GroupBox grpThucAn = null!;

    private RadioButton rdoCafeDen = null!;
    private RadioButton rdoCafeDa = null!;
    private RadioButton rdoCafeSua = null!;
    private RadioButton rdoCafeSuaDa = null!;
    private RadioButton rdoCafeKem = null!;

    private RadioButton rdoBanhMiTrung = null!;
    private RadioButton rdoBanhMiCa = null!;
    private RadioButton rdoMiTomTrung = null!;
    private RadioButton rdoMiXaoBo = null!;
    private RadioButton rdoMiCay = null!;

    private CheckBox chkSinhVien = null!;

    private Button btnTinhTien = null!;
    private Button btnNhapLai = null!;
    private Button btnThanhToan = null!;
    private Button btnThoat = null!;

    private ErrorProvider errorProvider1 = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        lblTenKhach = new Label();
        lblSoKhach = new Label();
        lblCafe = new Label();
        lblThucAn = new Label();
        lblTongKhach = new Label();
        lblTongTien = new Label();

        txtTenKhach = new TextBox();
        txtSoKhach = new TextBox();
        txtTongKhach = new TextBox();
        txtTongTien = new TextBox();

        grpCafe = new GroupBox();
        grpThucAn = new GroupBox();

        rdoCafeDen = new RadioButton();
        rdoCafeDa = new RadioButton();
        rdoCafeSua = new RadioButton();
        rdoCafeSuaDa = new RadioButton();
        rdoCafeKem = new RadioButton();

        rdoBanhMiTrung = new RadioButton();
        rdoBanhMiCa = new RadioButton();
        rdoMiTomTrung = new RadioButton();
        rdoMiXaoBo = new RadioButton();
        rdoMiCay = new RadioButton();

        chkSinhVien = new CheckBox();

        btnTinhTien = new Button();
        btnNhapLai = new Button();
        btnThanhToan = new Button();
        btnThoat = new Button();

        errorProvider1 = new ErrorProvider(components);

        SuspendLayout();

        // lblTenKhach
        lblTenKhach.AutoSize = true;
        lblTenKhach.Location = new Point(30, 25);
        lblTenKhach.Text = "Tên khách hàng:";

        // txtTenKhach
        txtTenKhach.Location = new Point(145, 20);
        txtTenKhach.Name = "txtTenKhach";
        txtTenKhach.Size = new Size(280, 23);
        txtTenKhach.TabIndex = 0;
        txtTenKhach.TextChanged += Input_Changed;

        // lblSoKhach
        lblSoKhach.AutoSize = true;
        lblSoKhach.Location = new Point(30, 60);
        lblSoKhach.Text = "Số khách:";

        // txtSoKhach
        txtSoKhach.Location = new Point(145, 55);
        txtSoKhach.Name = "txtSoKhach";
        txtSoKhach.Size = new Size(120, 23);
        txtSoKhach.TabIndex = 1;
        txtSoKhach.KeyPress += txtSoKhach_KeyPress;
        txtSoKhach.TextChanged += Input_Changed;

        // grpCafe
        grpCafe.Location = new Point(30, 95);
        grpCafe.Name = "grpCafe";
        grpCafe.Size = new Size(310, 190);
        grpCafe.Text = "Loại cafe";

        // Cafe đen
        rdoCafeDen.AutoSize = true;
        rdoCafeDen.Location = new Point(20, 30);
        rdoCafeDen.Text = "Cafe đen - 20.000đ";
        rdoCafeDen.CheckedChanged += LuaChon_Changed;

        // Cafe đá
        rdoCafeDa.AutoSize = true;
        rdoCafeDa.Location = new Point(20, 60);
        rdoCafeDa.Text = "Cafe đá - 25.000đ";
        rdoCafeDa.CheckedChanged += LuaChon_Changed;

        // Cafe sữa
        rdoCafeSua.AutoSize = true;
        rdoCafeSua.Location = new Point(20, 90);
        rdoCafeSua.Text = "Cafe sữa - 25.000đ";
        rdoCafeSua.CheckedChanged += LuaChon_Changed;

        // Cafe sữa đá
        rdoCafeSuaDa.AutoSize = true;
        rdoCafeSuaDa.Location = new Point(20, 120);
        rdoCafeSuaDa.Text = "Cafe sữa đá - 30.000đ";
        rdoCafeSuaDa.CheckedChanged += LuaChon_Changed;

        // Cafe kem
        rdoCafeKem.AutoSize = true;
        rdoCafeKem.Location = new Point(20, 150);
        rdoCafeKem.Text = "Cafe kem - 35.000đ";
        rdoCafeKem.CheckedChanged += LuaChon_Changed;

        grpCafe.Controls.Add(rdoCafeDen);
        grpCafe.Controls.Add(rdoCafeDa);
        grpCafe.Controls.Add(rdoCafeSua);
        grpCafe.Controls.Add(rdoCafeSuaDa);
        grpCafe.Controls.Add(rdoCafeKem);

        // grpThucAn
        grpThucAn.Location = new Point(360, 95);
        grpThucAn.Name = "grpThucAn";
        grpThucAn.Size = new Size(310, 190);
        grpThucAn.Text = "Thức ăn";

        // Bánh mì trứng
        rdoBanhMiTrung.AutoSize = true;
        rdoBanhMiTrung.Location = new Point(20, 30);
        rdoBanhMiTrung.Text = "Bánh mỳ trứng - 15.000đ";
        rdoBanhMiTrung.CheckedChanged += LuaChon_Changed;

        // Bánh mì cá
        rdoBanhMiCa.AutoSize = true;
        rdoBanhMiCa.Location = new Point(20, 60);
        rdoBanhMiCa.Text = "Bánh mỳ cá - 15.000đ";
        rdoBanhMiCa.CheckedChanged += LuaChon_Changed;

        // Mỳ tôm trứng
        rdoMiTomTrung.AutoSize = true;
        rdoMiTomTrung.Location = new Point(20, 90);
        rdoMiTomTrung.Text = "Mỳ tôm trứng - 20.000đ";
        rdoMiTomTrung.CheckedChanged += LuaChon_Changed;

        // Mỳ xào bò
        rdoMiXaoBo.AutoSize = true;
        rdoMiXaoBo.Location = new Point(20, 120);
        rdoMiXaoBo.Text = "Mỳ xào bò - 30.000đ";
        rdoMiXaoBo.CheckedChanged += LuaChon_Changed;

        // Mỳ cay
        rdoMiCay.AutoSize = true;
        rdoMiCay.Location = new Point(20, 150);
        rdoMiCay.Text = "Mỳ cay - 50.000đ";
        rdoMiCay.CheckedChanged += LuaChon_Changed;

        grpThucAn.Controls.Add(rdoBanhMiTrung);
        grpThucAn.Controls.Add(rdoBanhMiCa);
        grpThucAn.Controls.Add(rdoMiTomTrung);
        grpThucAn.Controls.Add(rdoMiXaoBo);
        grpThucAn.Controls.Add(rdoMiCay);

        // Sinh viên
        chkSinhVien.AutoSize = true;
        chkSinhVien.Location = new Point(30, 300);
        chkSinhVien.Name = "chkSinhVien";
        chkSinhVien.Text = "Sinh viên - giảm 20%";
        chkSinhVien.CheckedChanged += LuaChon_Changed;

        // btnTinhTien
        btnTinhTien.Location = new Point(30, 345);
        btnTinhTien.Name = "btnTinhTien";
        btnTinhTien.Size = new Size(110, 35);
        btnTinhTien.Text = "Tính tiền";
        btnTinhTien.Enabled = false;
        btnTinhTien.UseVisualStyleBackColor = true;
        btnTinhTien.Click += btnTinhTien_Click;

        // btnNhapLai
        btnNhapLai.Location = new Point(155, 345);
        btnNhapLai.Name = "btnNhapLai";
        btnNhapLai.Size = new Size(110, 35);
        btnNhapLai.Text = "Nhập lại";
        btnNhapLai.Enabled = false;
        btnNhapLai.UseVisualStyleBackColor = true;
        btnNhapLai.Click += btnNhapLai_Click;

        // btnThanhToan
        btnThanhToan.Location = new Point(280, 345);
        btnThanhToan.Name = "btnThanhToan";
        btnThanhToan.Size = new Size(110, 35);
        btnThanhToan.Text = "Thanh toán";
        btnThanhToan.Enabled = false;
        btnThanhToan.UseVisualStyleBackColor = true;
        btnThanhToan.Click += btnThanhToan_Click;

        // btnThoat
        btnThoat.Location = new Point(405, 345);
        btnThoat.Name = "btnThoat";
        btnThoat.Size = new Size(100, 35);
        btnThoat.Text = "Thoát";
        btnThoat.UseVisualStyleBackColor = true;
        btnThoat.Click += btnThoat_Click;

        // Tổng khách
        lblTongKhach.AutoSize = true;
        lblTongKhach.Location = new Point(30, 405);
        lblTongKhach.Text = "Tổng số khách:";

        txtTongKhach.Location = new Point(145, 400);
        txtTongKhach.Name = "txtTongKhach";
        txtTongKhach.ReadOnly = true;
        txtTongKhach.Size = new Size(120, 23);

        // Tổng tiền
        lblTongTien.AutoSize = true;
        lblTongTien.Location = new Point(300, 405);
        lblTongTien.Text = "Tổng tiền:";

        txtTongTien.Location = new Point(365, 400);
        txtTongTien.Name = "txtTongTien";
        txtTongTien.ReadOnly = true;
        txtTongTien.Size = new Size(140, 23);

        // ErrorProvider
        errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;

        // Form
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(720, 455);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Name = "frmBai09";
        Text = "Lab04 - Bài nâng cao: Thu tiền Cafe Sinh Viên";

        Controls.Add(lblTenKhach);
        Controls.Add(txtTenKhach);
        Controls.Add(lblSoKhach);
        Controls.Add(txtSoKhach);

        Controls.Add(grpCafe);
        Controls.Add(grpThucAn);

        Controls.Add(chkSinhVien);

        Controls.Add(btnTinhTien);
        Controls.Add(btnNhapLai);
        Controls.Add(btnThanhToan);
        Controls.Add(btnThoat);

        Controls.Add(lblTongKhach);
        Controls.Add(txtTongKhach);
        Controls.Add(lblTongTien);
        Controls.Add(txtTongTien);

        Load += frmBai09_Load;
        FormClosing += frmBai09_FormClosing;

        ResumeLayout(false);
        PerformLayout();
    }
}