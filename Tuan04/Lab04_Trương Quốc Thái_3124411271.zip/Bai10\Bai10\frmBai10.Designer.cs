﻿#nullable enable

namespace Bai10;

partial class frmBai10
{
    private System.ComponentModel.IContainer? components = null;

    private TextBox txtManHinh = null!;

    private Button btn0 = null!;
    private Button btn1 = null!;
    private Button btn2 = null!;
    private Button btn3 = null!;
    private Button btn4 = null!;
    private Button btn5 = null!;
    private Button btn6 = null!;
    private Button btn7 = null!;
    private Button btn8 = null!;
    private Button btn9 = null!;

    private Button btnCong = null!;
    private Button btnTru = null!;
    private Button btnNhan = null!;
    private Button btnChia = null!;

    private Button btnCham = null!;
    private Button btnBang = null!;
    private Button btnXoa = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        txtManHinh = new TextBox();

        btn0 = new Button();
        btn1 = new Button();
        btn2 = new Button();
        btn3 = new Button();
        btn4 = new Button();
        btn5 = new Button();
        btn6 = new Button();
        btn7 = new Button();
        btn8 = new Button();
        btn9 = new Button();

        btnCong = new Button();
        btnTru = new Button();
        btnNhan = new Button();
        btnChia = new Button();

        btnCham = new Button();
        btnBang = new Button();
        btnXoa = new Button();

        SuspendLayout();

        // Màn hình
        txtManHinh.Location = new Point(30, 25);
        txtManHinh.Name = "txtManHinh";
        txtManHinh.ReadOnly = true;
        txtManHinh.Size = new Size(310, 40);
        txtManHinh.Font = new Font(
            "Segoe UI",
            16F);
        txtManHinh.TextAlign = HorizontalAlignment.Right;

        // Các nút số
        TaoButtonSo(btn7, "7", 30, 90);
        TaoButtonSo(btn8, "8", 110, 90);
        TaoButtonSo(btn9, "9", 190, 90);

        TaoButtonSo(btn4, "4", 30, 150);
        TaoButtonSo(btn5, "5", 110, 150);
        TaoButtonSo(btn6, "6", 190, 150);

        TaoButtonSo(btn1, "1", 30, 210);
        TaoButtonSo(btn2, "2", 110, 210);
        TaoButtonSo(btn3, "3", 190, 210);

        TaoButtonSo(btn0, "0", 30, 270);

        // Phép toán
        TaoButtonPhepToan(
            btnCong,
            "+",
            270,
            90);

        TaoButtonPhepToan(
            btnTru,
            "-",
            270,
            150);

        TaoButtonPhepToan(
            btnNhan,
            "x",
            270,
            210);

        TaoButtonPhepToan(
            btnChia,
            "/",
            270,
            270);

        // Dấu chấm
        btnCham.Location = new Point(110, 270);
        btnCham.Size = new Size(60, 45);
        btnCham.Text = ".";
        btnCham.Click += btnCham_Click;

        // Bằng
        btnBang.Location = new Point(110, 330);
        btnBang.Size = new Size(140, 45);
        btnBang.Text = "=";
        btnBang.Click += btnBang_Click;

        // Xóa
        btnXoa.Location = new Point(30, 330);
        btnXoa.Size = new Size(60, 45);
        btnXoa.Text = "C";
        btnXoa.Click += btnXoa_Click;

        Controls.Add(txtManHinh);

        Controls.Add(btn0);
        Controls.Add(btn1);
        Controls.Add(btn2);
        Controls.Add(btn3);
        Controls.Add(btn4);
        Controls.Add(btn5);
        Controls.Add(btn6);
        Controls.Add(btn7);
        Controls.Add(btn8);
        Controls.Add(btn9);

        Controls.Add(btnCong);
        Controls.Add(btnTru);
        Controls.Add(btnNhan);
        Controls.Add(btnChia);

        Controls.Add(btnCham);
        Controls.Add(btnBang);
        Controls.Add(btnXoa);

        AutoScaleDimensions =
            new SizeF(7F, 15F);

        AutoScaleMode =
            AutoScaleMode.Font;

        ClientSize =
            new Size(370, 410);

        Name = "frmBai10";
        StartPosition =
            FormStartPosition.CenterScreen;

        Text =
            "Lab04 - Bài 10: Máy tính bỏ túi";

        FormClosing +=
            frmBai10_FormClosing;

        ResumeLayout(false);
        PerformLayout();
    }

    private void TaoButtonSo(
        Button button,
        string text,
        int x,
        int y)
    {
        button.Location =
            new Point(x, y);

        button.Size =
            new Size(60, 45);

        button.Text = text;

        button.Click +=
            btnSo_Click;
    }

    private void TaoButtonPhepToan(
        Button button,
        string text,
        int x,
        int y)
    {
        button.Location =
            new Point(x, y);

        button.Size =
            new Size(60, 45);

        button.Text = text;

        button.Click +=
            btnPhepToan_Click;
    }
}