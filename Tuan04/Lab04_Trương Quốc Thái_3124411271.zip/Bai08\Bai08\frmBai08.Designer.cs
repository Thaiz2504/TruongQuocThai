﻿#nullable enable

namespace Bai08;

partial class frmBai08
{
    private System.ComponentModel.IContainer? components = null;

    private Panel pnlGhe = null!;
    private Label lblTieuDe = null!;
    private Label lblThanhTienText = null!;
    private Label lblThanhTien = null!;

    private Button btnChon = null!;
    private Button btnHuyBo = null!;
    private Button btnThoat = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        lblTieuDe = new Label();
        pnlGhe = new Panel();

        lblThanhTienText = new Label();
        lblThanhTien = new Label();

        btnChon = new Button();
        btnHuyBo = new Button();
        btnThoat = new Button();

        SuspendLayout();

        // lblTieuDe
        lblTieuDe.AutoSize = true;
        lblTieuDe.Font = new Font(
            "Segoe UI",
            14F,
            FontStyle.Bold);

        lblTieuDe.Location = new Point(250, 20);
        lblTieuDe.Name = "lblTieuDe";
        lblTieuDe.Text = "QUẢN LÝ BÁN VÉ RẠP PHIM";

        // pnlGhe
        pnlGhe.Location = new Point(120, 70);
        pnlGhe.Name = "pnlGhe";
        pnlGhe.Size = new Size(520, 260);
        pnlGhe.BorderStyle = BorderStyle.FixedSingle;

        // lblThanhTienText
        lblThanhTienText.AutoSize = true;
        lblThanhTienText.Location = new Point(120, 355);
        lblThanhTienText.Font = new Font(
            "Segoe UI",
            11F,
            FontStyle.Bold);
        lblThanhTienText.Text = "Thành tiền:";

        // lblThanhTien
        lblThanhTien.AutoSize = true;
        lblThanhTien.Location = new Point(220, 355);
        lblThanhTien.Font = new Font(
            "Segoe UI",
            11F,
            FontStyle.Bold);
        lblThanhTien.Text = "0";

        // btnChon
        btnChon.Location = new Point(270, 350);
        btnChon.Size = new Size(100, 35);
        btnChon.Name = "btnChon";
        btnChon.Text = "CHỌN";
        btnChon.UseVisualStyleBackColor = true;
        btnChon.Click += btnChon_Click;

        // btnHuyBo
        btnHuyBo.Location = new Point(390, 350);
        btnHuyBo.Size = new Size(100, 35);
        btnHuyBo.Name = "btnHuyBo";
        btnHuyBo.Text = "HỦY BỎ";
        btnHuyBo.UseVisualStyleBackColor = true;
        btnHuyBo.Click += btnHuyBo_Click;

        // btnThoat
        btnThoat.Location = new Point(510, 350);
        btnThoat.Size = new Size(100, 35);
        btnThoat.Name = "btnThoat";
        btnThoat.Text = "THOÁT";
        btnThoat.UseVisualStyleBackColor = true;
        btnThoat.Click += btnThoat_Click;

        // Form
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;

        ClientSize = new Size(760, 430);

        Controls.Add(btnThoat);
        Controls.Add(btnHuyBo);
        Controls.Add(btnChon);
        Controls.Add(lblThanhTien);
        Controls.Add(lblThanhTienText);
        Controls.Add(pnlGhe);
        Controls.Add(lblTieuDe);

        Name = "frmBai08";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Lab04 - Bài nâng cao: Bán vé rạp phim";

        FormClosing += frmBai08_FormClosing;

        ResumeLayout(false);
        PerformLayout();
    }
}