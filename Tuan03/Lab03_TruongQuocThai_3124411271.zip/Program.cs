﻿using System;
using System.Linq;

namespace BaiThucHanhLINQ;

class Program
{
    static void Main()
    {
        Bai21();
        Bai22();
        Bai31(); 
        Bai32();
        Bai51();
        Bai52();
        Bai62();
    }

    // Bài 2.1. Truy vấn mảng số nguyên
    static void Bai21()
    {
        int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };

        Console.WriteLine("========== BÀI 2.1 - TRUY VẤN MẢNG SỐ NGUYÊN ==========");

        // ==================================================
        // Câu a: Liệt kê các phần tử chia hết cho 4 và 3
        // ==================================================

        Console.WriteLine("\n--- Câu a: Phần tử chia hết cho 4 và 3 ---");

        // Query Syntax
        var cauA_Query =
            from n in mangSo
            where n % 4 == 0 && n % 3 == 0
            select n;

        Console.WriteLine("Query Syntax:");
        foreach (var n in cauA_Query)
        {
            Console.Write($"{n} ");
        }

        Console.WriteLine();

        // Method Syntax
        var cauA_Method = mangSo
            .Where(n => n % 4 == 0 && n % 3 == 0);

        Console.WriteLine("Method Syntax:");
        foreach (var n in cauA_Method)
        {
            Console.Write($"{n} ");
        }

        Console.WriteLine();

        // ==================================================
        // Câu b: Liệt kê các phần tử <= 3
        // ==================================================

        Console.WriteLine("\n--- Câu b: Các phần tử nhỏ hơn hoặc bằng 3 ---");

        // Query Syntax
        var cauB_Query =
            from n in mangSo
            where n <= 3
            select n;

        Console.WriteLine("Query Syntax:");
        foreach (var n in cauB_Query)
        {
            Console.Write($"{n} ");
        }

        Console.WriteLine();

        // Method Syntax
        var cauB_Method = mangSo
            .Where(n => n <= 3);

        Console.WriteLine("Method Syntax:");
        foreach (var n in cauB_Method)
        {
            Console.Write($"{n} ");
        }

        Console.WriteLine();

        // ==================================================
        // Câu c:
        // Số chẵn chia đôi, số lẻ giữ nguyên giá trị
        // ==================================================

        Console.WriteLine("\n--- Câu c: Số chẵn chia đôi, số lẻ giữ nguyên ---");

        // Method Syntax
        var cauC = mangSo.Select(n =>
            n % 2 == 0 ? n / 2 : n
        );

        Console.WriteLine("Kết quả:");
        foreach (var n in cauC)
        {
            Console.Write($"{n} ");
        }

        Console.WriteLine();
    }
// Bài 2.2. Truy vấn mảng chuỗi
static void Bai22()
{
    string[] mangChuoi =
    {
        "đầu", "lòng", "hai", "ả", "tố", "nga",
        "Thúy", "Kiều", "là", "chị", "em",
        "là", "Thúy", "Vân"
    };

    Console.WriteLine("\n\n========== BÀI 2.2 - TRUY VẤN MẢNG CHUỖI ==========");

    // ==================================================
    // Câu a: Các phần tử có 4 ký tự,
    //         sắp xếp tăng dần theo ký tự đầu tiên
    // ==================================================

    Console.WriteLine("\n--- Câu a: Phần tử có 4 ký tự, sắp xếp theo ký tự đầu ---");

    // Query Syntax
    var cauA_Query =
        from s in mangChuoi
        where s.Length == 4
        orderby s[0]
        select s;

    Console.WriteLine("Query Syntax:");
    foreach (var s in cauA_Query)
    {
        Console.Write($"{s} ");
    }

    Console.WriteLine();

    // Method Syntax
    var cauA_Method = mangChuoi
        .Where(s => s.Length == 4)
        .OrderBy(s => s[0]);

    Console.WriteLine("Method Syntax:");
    foreach (var s in cauA_Method)
    {
        Console.Write($"{s} ");
    }

    Console.WriteLine();

    // ==================================================
    // Câu b: <chữ thường> - <CHỮ HOA>
    // ==================================================

    Console.WriteLine("\n--- Câu b: Chuyển thành dạng chữ thường - CHỮ HOA ---");

    // Query Syntax
    var cauB_Query =
        from s in mangChuoi
        select $"{s.ToLower()} - {s.ToUpper()}";

    Console.WriteLine("Query Syntax:");
    foreach (var s in cauB_Query)
    {
        Console.WriteLine(s);
    }

    // Method Syntax
    var cauB_Method = mangChuoi
        .Select(s => $"{s.ToLower()} - {s.ToUpper()}");

    Console.WriteLine("Method Syntax:");
    foreach (var s in cauB_Method)
    {
        Console.WriteLine(s);
    }

    // ==================================================
    // Câu c: Các phần tử chứa ký tự "u"
    // ==================================================

    Console.WriteLine("\n--- Câu c: Phần tử chứa ký tự \"u\" ---");

    // Query Syntax
    var cauC_Query =
        from s in mangChuoi
        where s.Contains("u")
        select s;

    Console.WriteLine("Query Syntax:");
    foreach (var s in cauC_Query)
    {
        Console.Write($"{s} ");
    }

    Console.WriteLine();

    // Method Syntax
    var cauC_Method = mangChuoi
        .Where(s => s.Contains("u"));

    Console.WriteLine("Method Syntax:");
    foreach (var s in cauC_Method)
    {
        Console.Write($"{s} ");
    }

    Console.WriteLine();

    // ==================================================
    // Câu d: Các phần tử bắt đầu bằng chữ in hoa
    // ==================================================

    Console.WriteLine("\n--- Câu d: Các từ bắt đầu bằng chữ in hoa ---");

    // Query Syntax
    var cauD_Query =
        from s in mangChuoi
        where char.IsUpper(s[0])
        select s;

    Console.WriteLine("Query Syntax:");
    Console.WriteLine(string.Join(" ", cauD_Query));

    // Method Syntax
    var cauD_Method = mangChuoi
        .Where(s => char.IsUpper(s[0]));

    Console.WriteLine("Method Syntax:");
    Console.WriteLine(string.Join(" ", cauD_Method));
    Console.WriteLine();
    }

// Bài 3.1. Thống kê mảng số
static void Bai31()
{
    int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };

    Console.WriteLine("\n\n========== BÀI 3.1 - THỐNG KÊ MẢNG SỐ ==========");

    // ==================================================
    // Câu a: Tổng số phần tử, số chẵn, số lẻ
    // ==================================================

    Console.WriteLine("\n--- Câu a: Thống kê số phần tử ---");

    int tongSoPhanTu = mangSo.Count();
    int soPhanTuChan = mangSo.Count(n => n % 2 == 0);
    int soPhanTuLe = mangSo.Count(n => n % 2 != 0);

    Console.WriteLine($"Tổng số phần tử: {tongSoPhanTu}");
    Console.WriteLine($"Số phần tử chẵn: {soPhanTuChan}");
    Console.WriteLine($"Số phần tử lẻ: {soPhanTuLe}");

    // ==================================================
    // Câu b: Tổng, lớn nhất, nhỏ nhất
    // ==================================================

    Console.WriteLine("\n--- Câu b: Tổng, giá trị lớn nhất, nhỏ nhất ---");

    int tong = mangSo.Sum();
    int lonNhat = mangSo.Max();
    int nhoNhat = mangSo.Min();

    Console.WriteLine($"Tổng các giá trị: {tong}");
    Console.WriteLine($"Giá trị lớn nhất: {lonNhat}");
    Console.WriteLine($"Giá trị nhỏ nhất: {nhoNhat}");

    // ==================================================
    // Câu c: Có bao nhiêu giá trị khác nhau
    // ==================================================

    Console.WriteLine("\n--- Câu c: Số lượng giá trị khác nhau ---");

    int soGiaTriKhacNhau = mangSo
        .Distinct()
        .Count();

    Console.WriteLine($"Có {soGiaTriKhacNhau} giá trị khác nhau.");

    // ==================================================
    // Câu d: Phân nhóm theo số dư khi chia cho 5
    // ==================================================

    Console.WriteLine("\n--- Câu d: Phân nhóm theo số dư khi chia cho 5 ---");

    var nhomTheoSoDu = mangSo
        .GroupBy(n => n % 5)
        .OrderBy(g => g.Key);

    foreach (var nhom in nhomTheoSoDu)
    {
        Console.Write($"Số dư {nhom.Key}: ");

        foreach (var n in nhom)
        {
            Console.Write($"{n} ");
        }

            Console.WriteLine();
    }
}
     // Bài 3.2. Thống kê mảng chuỗi
static void Bai32()
{
    string[] monAn =
    {
        "Bún bò Huế",
        "Hủ tiếu heo",
        "Bánh canh",
        "Bánh mì",
        "Nước Cà phê",
        "Mì quảng",
        "Cơm tấm",
        "Nước Chanh dây",
        "Mì xào",
        "Bún riêu",
        "Bánh cuốn",
        "Mì gói",
        "Bún chả",
        "Hủ tiếu Nam vang"
    };

    Console.WriteLine("\n\n========== BÀI 3.2 - THỐNG KÊ MẢNG CHUỖI ==========");

    // ==================================================
    // Câu a: Tìm phần tử có chiều dài ngắn nhất và dài nhất
    // ==================================================

    Console.WriteLine("\n--- Câu a: Phần tử ngắn nhất và dài nhất ---");

    int doDaiNhoNhat = monAn.Min(mon => mon.Length);
    int doDaiLonNhat = monAn.Max(mon => mon.Length);

    var monNganNhat = monAn
        .Where(mon => mon.Length == doDaiNhoNhat);

    var monDaiNhat = monAn
        .Where(mon => mon.Length == doDaiLonNhat);

    Console.WriteLine($"Chiều dài ngắn nhất: {doDaiNhoNhat}");
    Console.WriteLine("Món ăn có chiều dài ngắn nhất:");

    foreach (var mon in monNganNhat)
    {
        Console.WriteLine($"- {mon}");
    }

    Console.WriteLine($"Chiều dài dài nhất: {doDaiLonNhat}");
    Console.WriteLine("Món ăn có chiều dài dài nhất:");

    foreach (var mon in monDaiNhat)
    {
        Console.WriteLine($"- {mon}");
    }

    // ==================================================
    // Câu b: Phân nhóm theo từ đầu tiên
    // ==================================================

    Console.WriteLine("\n--- Câu b: Phân nhóm theo từ đầu tiên ---");

    var nhomTheoTuDau = monAn
        .GroupBy(mon => mon.Split(' ')[0]);

    foreach (var nhom in nhomTheoTuDau)
    {
        Console.WriteLine($"Nhóm {nhom.Key}:");

        foreach (var mon in nhom)
        {
            Console.WriteLine($"  - {mon}");
        }
    }

    // ==================================================
    // Câu c: Đếm số phần tử có từ đầu tiên là "Bánh"
    // ==================================================

    Console.WriteLine("\n--- Câu c: Số món có từ đầu tiên là \"Bánh\" ---");

    int soMonBanh = monAn
        .Count(mon => mon.StartsWith("Bánh "));

    Console.WriteLine($"Có {soMonBanh} món có từ đầu tiên là \"Bánh\".");
}     
// Bài 5.1. Truy vấn cơ bản
static void Bai51()
{
    List<MonHoc> dsMon = DuLieu.DS_Mon();

    Console.WriteLine("\n\n========== BÀI 5.1 - TRUY VẤN CƠ BẢN ==========");

    // ==================================================
    // Câu a: Liệt kê tên các môn học bắt đầu bằng "Lập trình"
    // ==================================================

    Console.WriteLine("\n--- Câu a: Các môn bắt đầu bằng \"Lập trình\" ---");

    // Query Syntax
    var cauA_Query =
        from mon in dsMon
        where mon.TenMon.StartsWith("Lập trình")
        select mon.TenMon;

    Console.WriteLine("Query Syntax:");
    foreach (var tenMon in cauA_Query)
    {
        Console.WriteLine($"- {tenMon}");
    }

    // Method Syntax
    var cauA_Method = dsMon
        .Where(mon => mon.TenMon.StartsWith("Lập trình"))
        .Select(mon => mon.TenMon);

    Console.WriteLine("Method Syntax:");
    foreach (var tenMon in cauA_Method)
    {
        Console.WriteLine($"- {tenMon}");
    }

    // ==================================================
    // Câu b: Môn thuộc hệ CD,
    //         sắp xếp số tiết giảm dần,
    //         rồi mã môn tăng dần
    // ==================================================

    Console.WriteLine("\n--- Câu b: Môn hệ CD, sắp xếp số tiết giảm dần rồi mã môn tăng dần ---");

    // Query Syntax
    var cauB_Query =
        from mon in dsMon
        where mon.He == "CD"
        orderby mon.SoTiet descending, mon.MaMon ascending
        select mon;

    Console.WriteLine("Query Syntax:");
    foreach (var mon in cauB_Query)
    {
        Console.WriteLine(
            $"{mon.MaMon} | {mon.TenMon} | {mon.He} | {mon.SoTiet} tiết"
        );
    }

    // Method Syntax
    var cauB_Method = dsMon
        .Where(mon => mon.He == "CD")
        .OrderByDescending(mon => mon.SoTiet)
        .ThenBy(mon => mon.MaMon);

    Console.WriteLine("Method Syntax:");
    foreach (var mon in cauB_Method)
    {
        Console.WriteLine(
            $"{mon.MaMon} | {mon.TenMon} | {mon.He} | {mon.SoTiet} tiết"
        );
    }

    // ==================================================
    // Câu c: Tên môn chứa từ "web",
    //         chỉ lấy Tên môn và Hệ
    // ==================================================

    Console.WriteLine("\n--- Câu c: Môn có tên chứa từ \"web\" ---");

    // Query Syntax
    var cauC_Query =
        from mon in dsMon
        where mon.TenMon.ToLower().Contains("web")
        select new
        {
            TenMon = mon.TenMon,
            He = mon.He
        };

    Console.WriteLine("Query Syntax:");
    foreach (var mon in cauC_Query)
    {
        Console.WriteLine($"{mon.TenMon} | {mon.He}");
    }

    // Method Syntax
    var cauC_Method = dsMon
        .Where(mon => mon.TenMon.ToLower().Contains("web"))
        .Select(mon => new
        {
            TenMon = mon.TenMon,
            He = mon.He
        });

    Console.WriteLine("Method Syntax:");
    foreach (var mon in cauC_Method)
    {
        Console.WriteLine($"{mon.TenMon} | {mon.He}");
    }

    // ==================================================
    // Câu d: Các môn thuộc hệ KTV,
    //         sắp xếp tăng dần theo Mã môn
    // ==================================================

    Console.WriteLine("\n--- Câu d: Môn hệ KTV, sắp xếp tăng dần theo Mã môn ---");

    // Query Syntax
    var cauD_Query =
        from mon in dsMon
        where mon.He == "KTV"
        orderby mon.MaMon
        select mon;

    Console.WriteLine("Query Syntax:");
    foreach (var mon in cauD_Query)
    {
        Console.WriteLine(
            $"{mon.MaMon} | {mon.TenMon} | {mon.He} | {mon.SoTiet} tiết"
        );
    }

    // Method Syntax
    var cauD_Method = dsMon
        .Where(mon => mon.He == "KTV")
        .OrderBy(mon => mon.MaMon);

    Console.WriteLine("Method Syntax:");
    foreach (var mon in cauD_Method)
    {
        Console.WriteLine(
            $"{mon.MaMon} | {mon.TenMon} | {mon.He} | {mon.SoTiet} tiết"
        );
    }
}
 // Bài 5.2. Thống kê trên List<MonHoc>
static void Bai52()
{
    List<MonHoc> dsMon = DuLieu.DS_Mon();

    Console.WriteLine("\n\n========== BÀI 5.2 - THỐNG KÊ TRÊN LIST<MONHOC> ==========");

    // ==================================================
    // Câu a: Tổng số môn hiện có
    // ==================================================

    Console.WriteLine("\n--- Câu a: Tổng số môn hiện có ---");

    int tongSoMon = dsMon.Count();

    Console.WriteLine($"Tổng số môn: {tongSoMon}");

    // ==================================================
    // Câu b: Đếm số môn có tên bắt đầu bằng "Lập trình"
    // ==================================================

    Console.WriteLine("\n--- Câu b: Số môn bắt đầu bằng \"Lập trình\" ---");

    int soMonLapTrinh = dsMon.Count(
        mon => mon.TenMon.StartsWith("Lập trình")
    );

    Console.WriteLine(
        $"Số môn bắt đầu bằng \"Lập trình\": {soMonLapTrinh}"
    );

    // ==================================================
    // Câu c: Tổng số tiết của hệ KTV
    // ==================================================

    Console.WriteLine("\n--- Câu c: Tổng số tiết của hệ KTV ---");

    int tongSoTietKTV = dsMon
        .Where(mon => mon.He == "KTV")
        .Sum(mon => mon.SoTiet);

    Console.WriteLine($"Tổng số tiết hệ KTV: {tongSoTietKTV}");

    // ==================================================
    // Câu d: Tổng số môn của mỗi hệ
    // ==================================================

    Console.WriteLine("\n--- Câu d: Tổng số môn của mỗi hệ ---");

    var cauD = dsMon
        .GroupBy(mon => mon.He)
        .Select(nhom => new
        {
            He = nhom.Key,
            TongSoMon = nhom.Count()
        });

    foreach (var nhom in cauD)
    {
        string tenHe = string.IsNullOrEmpty(nhom.He)
            ? "(Chưa khai báo)"
            : nhom.He;

        Console.WriteLine(
            $"{tenHe} | Tổng số môn: {nhom.TongSoMon}"
        );
    }

    // ==================================================
    // Câu e: Nhóm theo số tiết,
    //         sắp xếp giảm dần theo số tiết
    // ==================================================

    Console.WriteLine("\n--- Câu e: Nhóm theo Số tiết ---");

    var cauE = dsMon
        .GroupBy(mon => mon.SoTiet)
        .OrderByDescending(nhom => nhom.Key);

    foreach (var nhom in cauE)
    {
        Console.WriteLine(
            $"Số tiết: {nhom.Key} | Tổng số môn: {nhom.Count()}"
        );
    }

    // ==================================================
    // Câu f: Môn học có số tiết cao nhất
    // ==================================================

    Console.WriteLine("\n--- Câu f: Môn học có số tiết cao nhất ---");

    byte soTietMax = dsMon.Max(mon => mon.SoTiet);

    var cauF = dsMon
        .Where(mon => mon.SoTiet == soTietMax);

    foreach (var mon in cauF)
    {
        Console.WriteLine(
            $"{mon.MaMon} | {mon.TenMon} | {mon.He} | {mon.SoTiet} tiết"
        );
    }

    // ==================================================
    // Câu g: Thống kê theo Hệ
    //         Tổng số môn, tổng số tiết,
    //         số tiết cao nhất, số tiết thấp nhất
    // ==================================================

    Console.WriteLine("\n--- Câu g: Thống kê theo Hệ ---");

    var cauG = dsMon
        .GroupBy(mon => mon.He)
        .Select(nhom => new
        {
            He = nhom.Key,
            TongSoMon = nhom.Count(),
            TongSoTiet = nhom.Sum(mon => mon.SoTiet),
            SoTietCaoNhat = nhom.Max(mon => mon.SoTiet),
            SoTietThapNhat = nhom.Min(mon => mon.SoTiet)
        });

    foreach (var nhom in cauG)
    {
        string tenHe = string.IsNullOrEmpty(nhom.He)
            ? "(Chưa khai báo)"
            : nhom.He;

        Console.WriteLine(
            $"{tenHe} | " +
            $"Số môn: {nhom.TongSoMon} | " +
            $"Tổng tiết: {nhom.TongSoTiet} | " +
            $"Max: {nhom.SoTietCaoNhat} | " +
            $"Min: {nhom.SoTietThapNhat}"
        );
    }

    // ==================================================
    // Câu h: Liệt kê các môn được phân nhóm theo Hệ
    // ==================================================

    Console.WriteLine("\n--- Câu h: Liệt kê môn học theo Hệ ---");

    var cauH = dsMon
        .GroupBy(mon => mon.He);

    foreach (var nhom in cauH)
    {
        string tenHe = string.IsNullOrEmpty(nhom.Key)
            ? "(Chưa khai báo)"
            : nhom.Key;

        Console.WriteLine($"\nHệ: {tenHe}");

        foreach (var mon in nhom)
        {
            Console.WriteLine(
                $"  {mon.MaMon} | {mon.TenMon} | {mon.SoTiet} tiết"
            );
        }
    }

    // ==================================================
    // Câu i: Phân nhóm theo Số tiết
    //         và tăng dần theo Số tiết
    // ==================================================

    Console.WriteLine("\n--- Câu i: Phân nhóm theo Số tiết tăng dần ---");

    var cauI = dsMon
        .GroupBy(mon => mon.SoTiet)
        .OrderBy(nhom => nhom.Key);

    foreach (var nhom in cauI)
    {
        Console.WriteLine($"\nSố tiết: {nhom.Key}");

        foreach (var mon in nhom)
        {
            Console.WriteLine(
                $"  {mon.MaMon} | {mon.TenMon}"
            );
        }
    }

    // ==================================================
    // Câu j: Với hệ KTV, phân nhóm theo HP2, HP3, HP4, HP5
    //         và sắp xếp theo Mã môn
    // ==================================================

    Console.WriteLine("\n--- Câu j: Hệ KTV phân nhóm HP2, HP3, HP4, HP5 ---");

    var cauJ = dsMon
        .Where(mon => mon.He == "KTV")
        .GroupBy(mon => mon.MaMon.Substring(0, 3))
        .OrderBy(nhom => nhom.Key);

    foreach (var nhom in cauJ)
    {
        Console.WriteLine($"\nHọc phần: {nhom.Key}");

        foreach (var mon in nhom.OrderBy(mon => mon.MaMon))
        {
            Console.WriteLine(
                $"  {mon.MaMon} | {mon.TenMon} | {mon.SoTiet} tiết"
            );
        }
    }

    // ==================================================
    // Câu k: Phân nhóm theo Hệ,
    //         chỉ lấy môn có Số tiết > 40,
    //         trong mỗi nhóm sắp xếp theo Mã môn
    // ==================================================

    Console.WriteLine(
        "\n--- Câu k: Phân nhóm theo Hệ, Số tiết > 40 ---"
    );

    var cauK = dsMon
        .Where(mon => mon.SoTiet > 40)
        .GroupBy(mon => mon.He)
        .OrderBy(nhom => nhom.Key);

    foreach (var nhom in cauK)
    {
        string tenHe = string.IsNullOrEmpty(nhom.Key)
            ? "(Chưa khai báo)"
            : nhom.Key;

        Console.WriteLine($"\nHệ: {tenHe}");

        foreach (var mon in nhom.OrderBy(mon => mon.MaMon))
        {
            Console.WriteLine(
                $"  {mon.MaMon} | {mon.TenMon} | {mon.SoTiet} tiết"
            );
        }
    }
}   
// Bài 6.2. Join và các toán tử tập hợp
static void Bai62()
{
    List<MonHoc> dsMon = DuLieu.DS_Mon();
    List<He> dsHe = DuLieu.DS_He();

    Console.WriteLine(
        "\n\n========== BÀI 6.2 - JOIN VÀ CÁC TOÁN TỬ TẬP HỢP =========="
    );

    // ==================================================
    // Câu a: Dùng join để liệt kê:
    //         Tên hệ, Mã môn, Tên môn
    // ==================================================

    Console.WriteLine("\n--- Câu a: JOIN - Tên hệ, Mã môn, Tên môn ---");

    var cauA =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
        select new
        {
            TenHe = h.TenHe,
            MaMon = m.MaMon,
            TenMon = m.TenMon
        };

    foreach (var item in cauA)
    {
        Console.WriteLine(
            $"{item.TenHe} | {item.MaMon} | {item.TenMon}"
        );
    }

    // ==================================================
    // Câu b: Left outer join bằng GroupJoin + DefaultIfEmpty
    //         Liệt kê cả hệ chưa có môn học
    // ==================================================

    Console.WriteLine(
        "\n--- Câu b: LEFT OUTER JOIN - Kể cả hệ chưa có môn ---"
    );

    var cauB =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
            into nhomMon
        from m in nhomMon.DefaultIfEmpty()
        select new
        {
            TenHe = h.TenHe,
            MaMon = m?.MaMon ?? "(Không có)",
            TenMon = m?.TenMon ?? "(Không có môn học)"
        };

    foreach (var item in cauB)
    {
        Console.WriteLine(
            $"{item.TenHe} | {item.MaMon} | {item.TenMon}"
        );
    }

    // ==================================================
    // Câu c:
    // Liệt kê cả hệ chưa có môn học
    // và môn học chưa khai báo hệ
    // ==================================================

    Console.WriteLine(
        "\n--- Câu c: FULL OUTER JOIN - Tất cả hệ và tất cả môn ---"
    );

    // Phần 1: tất cả hệ + môn tương ứng
    var leftJoin =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
            into nhomMon
        from m in nhomMon.DefaultIfEmpty()
        select new
        {
            TenHe = h.TenHe,
            MaMon = m?.MaMon ?? "(Không có)",
            TenMon = m?.TenMon ?? "(Không có môn học)"
        };

    // Phần 2: những môn chưa khai báo hệ
    var rightUnmatched =
        from m in dsMon
        join h in dsHe
            on m.He equals h.MaHe
            into nhomHe
        from h in nhomHe.DefaultIfEmpty()
        where h == null
        select new
        {
            TenHe = "(Không có hệ)",
            MaMon = m.MaMon,
            TenMon = m.TenMon
        };

    var cauC = leftJoin.Concat(rightUnmatched);

    foreach (var item in cauC)
    {
        Console.WriteLine(
            $"{item.TenHe} | {item.MaMon} | {item.TenMon}"
        );
    }

    // ==================================================
    // Câu d:
    // Chỉ liệt kê hệ chưa có môn
    // và môn học chưa khai báo hệ
    // ==================================================

    Console.WriteLine(
        "\n--- Câu d: CHỈ các phần tử không khớp ---"
    );

    // Hệ chưa có môn
    var heChuaCoMon =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
            into nhomMon
        from m in nhomMon.DefaultIfEmpty()
        where m == null
        select new
        {
            TenHe = h.TenHe,
            MaMon = "(Không có)",
            TenMon = "(Không có môn học)"
        };

    // Môn chưa khai báo hệ
    var monChuaCoHe =
        from m in dsMon
        join h in dsHe
            on m.He equals h.MaHe
            into nhomHe
        from h in nhomHe.DefaultIfEmpty()
        where h == null
        select new
        {
            TenHe = "(Không có hệ)",
            MaMon = m.MaMon,
            TenMon = m.TenMon
        };

    var cauD = heChuaCoMon.Concat(monChuaCoHe);

    foreach (var item in cauD)
    {
        Console.WriteLine(
            $"{item.TenHe} | {item.MaMon} | {item.TenMon}"
        );
    }

    // ==================================================
    // Câu e:
    // Lấy 5 môn đầu tiên có số tiết giảm dần
    // Hiển thị Tên hệ, Mã môn, Tên môn, Số tiết
    // ==================================================

    Console.WriteLine(
        "\n--- Câu e: 5 môn có số tiết cao nhất ---"
    );

    var cauE =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
        orderby m.SoTiet descending, m.MaMon ascending
        select new
        {
            TenHe = h.TenHe,
            MaMon = m.MaMon,
            TenMon = m.TenMon,
            SoTiet = m.SoTiet
        };

    foreach (var item in cauE.Take(5))
    {
        Console.WriteLine(
            $"{item.TenHe} | {item.MaMon} | " +
            $"{item.TenMon} | {item.SoTiet} tiết"
        );
    }

    // ==================================================
    // Câu f:
    // Tổng số môn học của mỗi hệ
    // Mã hệ, Tên hệ, Tổng số môn
    // ==================================================

    Console.WriteLine(
        "\n--- Câu f: Tổng số môn học của mỗi hệ ---"
    );

    var cauF =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
            into nhomMon
        select new
        {
            MaHe = h.MaHe,
            TenHe = h.TenHe,
            TongSoMon = nhomMon.Count()
        };

    foreach (var item in cauF)
    {
        Console.WriteLine(
            $"{item.MaHe} | {item.TenHe} | " +
            $"Tổng số môn: {item.TongSoMon}"
        );
    }

    // ==================================================
    // Câu g:
    // Có bao nhiêu loại Số tiết khác nhau
    // ==================================================

    Console.WriteLine(
        "\n--- Câu g: Số loại số tiết khác nhau ---"
    );

    int soLoaiTiet = dsMon
        .Select(m => m.SoTiet)
        .Distinct()
        .Count();

    Console.WriteLine(
        $"Có {soLoaiTiet} loại số tiết khác nhau."
    );

    // ==================================================
    // Câu h:
    // Môn học đầu tiên có tên bắt đầu bằng "Lập trình"
    // ==================================================

    Console.WriteLine(
        "\n--- Câu h: Môn đầu tiên bắt đầu bằng \"Lập trình\" ---"
    );

    var cauH = dsMon
        .FirstOrDefault(
            m => m.TenMon.StartsWith("Lập trình")
        );

    if (cauH != null)
    {
        Console.WriteLine(
            $"{cauH.MaMon} | {cauH.TenMon} | " +
            $"{cauH.He} | {cauH.SoTiet} tiết"
        );
    }
    else
    {
        Console.WriteLine("Không tìm thấy môn học.");
    }

    // ==================================================
    // Câu i:
    // Liệt kê các môn theo từng hệ,
    // đánh số thứ tự trong mỗi nhóm
    // ==================================================

    Console.WriteLine(
        "\n--- Câu i: Các môn theo từng hệ, có đánh số thứ tự ---"
    );

    var cauI =
        from h in dsHe
        join m in dsMon
            on h.MaHe equals m.He
            into nhomMon
        select new
        {
            MaHe = h.MaHe,
            TenHe = h.TenHe,
            MonHoc = nhomMon
                .OrderBy(m => m.MaMon)
                .Select((m, index) => new
                {
                    STT = index + 1,
                    m.MaMon,
                    m.TenMon,
                    m.SoTiet
                })
        };

    foreach (var he in cauI)
    {
        Console.WriteLine($"\nHệ: {he.MaHe} - {he.TenHe}");

        foreach (var mon in he.MonHoc)
        {
            Console.WriteLine(
                $"  {mon.STT}. {mon.MaMon} | " +
                $"{mon.TenMon} | {mon.SoTiet} tiết"
            );
        }
    }
}
}